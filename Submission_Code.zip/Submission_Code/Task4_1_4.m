clear; clc; close all;
% 加载数据
load('time-series.mat'); % 读取时间序列数据
y = y(:); % 确保 y 是列向量
N = length(y); % 样本数

% 初始化动态感知机参数
mu = 1e-5; % 学习率
order = 4; % AR(4) 预测模型
w = zeros(order + 1, 1); % 初始化权重 (包含 bias)
y_pred = zeros(N, 1); % 预测输出
e = zeros(N, 1); % 误差信号

% 选择缩放因子 a
a = 53; % 可以尝试 a = 0.5, 1, 1.5, 2 进行比较

% 使用带偏置项和缩放因子的 tanh 进行预测
for n = order+1:N
    x_n = [1; y(n-1:-1:n-order)]; % 扩展输入特征 (包含 bias)
    y_pred(n) = a * tanh(w' * x_n); % 预测值 (带 bias 和缩放因子)
    e(n) = y(n) - y_pred(n); % 误差计算
    w = w + mu * e(n) * x_n; % LMS 权重更新 (包含 bias)
end

% 计算均方误差 (MSE) 和预测增益 (Rp)
sigma_yhat2 = var(y_pred); % 计算信号 y 的方差 (包含均值)
sigma_e2 = mean(e.^2); % 计算预测误差的均方
Rp = 10 * log10(sigma_yhat2 / sigma_e2); % 计算预测增益 (dB)

% 绘制结果
figure;
plot(y, 'b', 'DisplayName', 'Original y[n] (Non-zero mean)');
hold on;
plot(y_pred, 'r--', 'DisplayName', ['Predicted y[n] with Bias & Scaling (a = ', num2str(a), ')']);
legend;
xlabel('Sample Index');
ylabel('Amplitude');
title(['Nonlinear Prediction with Bias & Scaling Activation: MSE = ', num2str(sigma_e2), ', Rp = ', num2str(Rp), ' dB']);
grid on;
hold off;
