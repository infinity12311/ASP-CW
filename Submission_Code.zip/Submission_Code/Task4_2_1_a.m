clear; clc; close all;
% 生成时间序列
t = ((2*pi)/100):((2*pi)/100):10*pi; 

% 生成不同频率的正弦信号
y1 = sin(t);      % 频率为 1
y2 = sin(0.5*t);  % 频率较低
y3 = sin(4*t);    % 频率较高

% 计算卷积
auto_conv_y1 = conv(y1, y1, 'same'); % y1 的自卷积
conv_y1_y2 = conv(y1, y2, 'same');   % y1 和 y2 的卷积
conv_y1_y3 = conv(y1, y3, 'same');   % y1 和 y3 的卷积

% 绘图
figure;

% 自卷积 y1 * y1
subplot(3,1,1);
plot(t, auto_conv_y1, 'b');
title('Auto-convolution of y1');
xlabel('Time');
ylabel('Amplitude');
grid on;

% 卷积 y1 * y2
subplot(3,1,2);
plot(t, conv_y1_y2, 'r');
title('Convolution of y1 with y2');
xlabel('Time');
ylabel('Amplitude');
grid on;

% 卷积 y1 * y3
subplot(3,1,3);
plot(t, conv_y1_y3, 'g');
title('Convolution of y1 with y3');
xlabel('Time');
ylabel('Amplitude');
grid on;
