clc; clear; close all;

%% **Load EEG Data**
load('EEG_Data/EEG_Data_Assignment2.mat'); % Ensure the correct file path

% Select EEG signal channel (can be changed to 'POz')
EEG_raw = Cz; 
fs = fs; % Sampling rate

% Set ANC parameters
N = length(EEG_raw); % Signal length
M = 15; % Filter order
mu = 0.01; % Learning rate
num_realizations = 1; % Single experiment run

% **Generate 50Hz Reference Noise**
t = (0:N-1)' / fs; % Time vector
reference_noise = sin(2 * pi * 50 * t) + sqrt(0.01) * randn(N, 1); % 50Hz sinusoid + Gaussian noise

% **Initialize ANC Filter**
w_ANC = zeros(M,1); % ANC linear predictor weights
EEG_cleaned = zeros(N,1); % Estimated clean EEG signal

%% **ANC LMS Iteration**
for n = M+1:N
    u_ANC = reference_noise(n:-1:n-M+1); % Reference input signal
    noise_estimate = w_ANC' * u_ANC; % Estimated noise
    EEG_cleaned(n) = EEG_raw(n) - noise_estimate; % Remove 50Hz interference
    w_ANC = w_ANC + mu * EEG_cleaned(n) * u_ANC; % LMS weight update
end

%% **Plot Spectrograms of Raw and Filtered EEG Signals**
window = hamming(1024); % Hamming window
noverlap = 512; % 50% overlap
nfft = 2048; % FFT points

figure;
subplot(2,1,1);
spectrogram(EEG_raw, window, noverlap, nfft, fs, 'yaxis');
title('Raw EEG Spectrogram');
colorbar;

subplot(2,1,2);
spectrogram(EEG_cleaned, window, noverlap, nfft, fs, 'yaxis');
title('ANC Processed EEG Spectrogram');
colorbar;

%% **Result Analysis**
fprintf('ANC processing complete. 50Hz noise removed. Please check the spectrogram.\n');


% clc; clear; close all;
% 
% %% **加载 EEG 数据**
% load('EEG_Data/EEG_Data_Assignment2.mat'); % 确保路径正确
% 
% % 选择 EEG 信号通道（可以更改为 'POz'）
% EEG_raw = Cz; 
% fs = fs; % 采样率
% 
% % 设置 ANC 参数
% N = length(EEG_raw); % 信号长度
% M = 15; % 滤波器阶数
% mu = 0.01; % 学习率
% num_realizations = 1; % 运行一次实验即可
% 
% % **生成 50Hz 参考噪声**
% t = (0:N-1)' / fs; % 时间向量
% reference_noise = sin(2 * pi * 50 * t) + sqrt(0.01) * randn(N, 1); % 50Hz 正弦波 + 高斯噪声
% 
% % **初始化 ANC 滤波器**
% w_ANC = zeros(M,1); % ANC 线性预测器权重
% EEG_cleaned = zeros(N,1); % 估计的干净 EEG 信号
% 
% %% **ANC LMS 迭代**
% for n = M+1:N
%     u_ANC = reference_noise(n:-1:n-M+1); % 参考输入信号
%     noise_estimate = w_ANC' * u_ANC; % 估计的噪声
%     EEG_cleaned(n) = EEG_raw(n) - noise_estimate; % 去除 50Hz 干扰
%     w_ANC = w_ANC + mu * EEG_cleaned(n) * u_ANC; % LMS 更新权重
% end
% 
% %% **绘制原始和去噪后的频谱**
% window = hamming(1024); % 汉明窗
% noverlap = 512; % 50% 重叠
% nfft = 2048; % FFT 点数
% 
% figure;
% subplot(2,1,1);
% spectrogram(EEG_raw, window, noverlap, nfft, fs, 'yaxis');
% title('原始 EEG 频谱');
% colorbar;
% 
% subplot(2,1,2);
% spectrogram(EEG_cleaned, window, noverlap, nfft, fs, 'yaxis');
% title('ANC 处理后的 EEG 频谱');
% colorbar;
% 
% %% **结果分析**
% fprintf('ANC 处理完成，已去除 50Hz 噪声。请查看频谱图。\n');
