%% ========== Parameters and Initialization ==========
clear; clc; close all;

% --- AR(2) coefficients and noise ---
a1 = 0.1;
a2 = 0.8;
sigma2_eta = 0.25;

% --- LMS related ---
mu_list = [0.05, 0.01];   % Two step sizes to compare
M = 2;                    % Filter order (predictor uses x(n-1), x(n-2))
N = 1000;                 % Data length per trial
numReal = 100;            % Number of repeated trials
steadyStart = 901;        % Start index of steady-state region (last 100 points)

% Array to store steady-state weights, size: (length(mu_list) x numReal x M)
w_steady_all = zeros(length(mu_list), numReal, M);

%% ========== 1. Run multiple trials for each step size ==========
for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);

    for realization = 1:numReal
        % --- (a) Generate AR(2) data ---
        w_noise = sqrt(sigma2_eta)*randn(N,1);
        x = zeros(N,1);
        x(1) = 0; x(2) = 0;  % Initial values
        for n = 3:N
            x(n) = a1*x(n-1) + a2*x(n-2) + w_noise(n);
        end

        % --- (b) Initialize LMS ---
        wLMS = zeros(M,1);   % Weight vector [w1; w2]
        w_record = zeros(M,N);  % To record weights at each step

        % --- (c) Online update point-by-point ---
        for n = 3:N
            u = [x(n-1); x(n-2)];   % Input vector
            x_hat = wLMS' * u;     % Predicted output
            e_n = x(n) - x_hat;    % Prediction error
            % LMS update
            wLMS = wLMS + mu * e_n * u;
            % Record current weights
            w_record(:,n) = wLMS;
        end

        % --- (d) Average over steady-state region (last 100 points) ---
        w_steady_all(mu_idx, realization, :) = ...
            mean(w_record(:, steadyStart:end), 2)';
    end
end

%% ========== 2. Compute average steady-state coefficients over 100 trials for each mu ==========
w_avg_final = zeros(length(mu_list), M);  % Size (2 x 2), stores [w1, w2]
for mu_idx = 1:length(mu_list)
    w_avg_final(mu_idx,:) = mean( squeeze(w_steady_all(mu_idx,:,:)), 1 );
end

%% ========== 3. Display results and compare to true coefficients ==========
true_coeff = [a1, a2];
fprintf('\n=== True AR(2) Coefficients: (a1, a2) = (%.3f, %.3f) ===\n', a1, a2);

for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);
    w_est = w_avg_final(mu_idx,:);
    fprintf('\n--- Step size mu = %.3f ---\n', mu);
    fprintf('Average steady-state coefficient estimates: [w1, w2] = [%.4f, %.4f]\n', w_est(1), w_est(2));
    fprintf('Difference from true values: [%.4f, %.4f]\n', abs(w_est(1)-a1), abs(w_est(2)-a2));
end
