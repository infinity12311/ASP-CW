%% ========== 1. Parameter Settings ==========
clear; clc; close all;

N = 1000;                  % Data length (same as original N)
sigma2_v = 0.5;            % Noise variance (original sqrt(1/2) -> sqrt(sigma2_v))
w_true = 0.9;              % True MA(1) system coefficient (only 0.9, logic estimates single coefficient)
mu_fixed_list = [0.01, 0.1];% Two fixed-step LMS learning rates
rho = 0.0003;              % Learning rate for GASS step-size update (same as original)
alpha = 0.5;               % Decay factor in Ang & Farhang algorithm (original was hard-coded 0.5)
mu_init = 0.01;            % Initial step size for GASS (same as original mu=0.01)
M = 1;                     % Filter order (original was 1)
num_trials = 100;          % Perform K Monte Carlo trials

%% ========== 2. Initialize Accumulators for Multi-Trial Results ==========
w_B_Avg = zeros(M, N+1);         % Benveniste
w_A_Avg = zeros(M, N+1);         % Ang & Farhang
w_M_Avg = zeros(M, N+1);         % Matthews
w_LMS_Avg_1 = zeros(M, N+1);     % Standard LMS (mu_fixed_list(1))
w_LMA_Avg_2 = zeros(M, N+1);     % Standard LMS (mu_fixed_list(2))

%% ========== 3. Start Monte Carlo Trials: Repeat K Times ==========
for k = 1:num_trials
    
    % ------ (a) Generate MA(1) Process Signal x(n) ------
    v = sqrt(sigma2_v) * randn(N,1);  % Driving white noise
    x = zeros(N,1);
    for n = 2:N
        % x(n) = 0.9 * v(n-1) + v(n)  (same logic as original eta)
        x(n) = w_true * v(n-1) + v(n);
    end
    
    % ------ (b) Benveniste Method ------
    w_B = zeros(M, N+1); 
    mu_B = zeros(1, N+1);
    e_B = zeros(1, N+1);
    phi_B = zeros(M, N+1);
    mu_B(M+2) = mu_init;  % Initial step size

    for n = (M+2):N
        u_n = v(n-1);  % Input u_n only needs v(n-1), since M=1
        d_n = x(n);
        w_n = w_B(:, n);
        mu_n = mu_B(n);
        
        % Error
        e_n = d_n - w_n' * u_n;
        e_B(n) = e_n;
        
        % Weight update
        w_B(:, n+1) = w_n + mu_n * e_n * u_n;
        
        % Update phi(n)
        u_nm1 = v(n-2);    % One step behind u_n
        phi_n_1 = phi_B(:, n-1);
        e_nm1 = e_B(n-1);
        
        % Benveniste formula: phi(n) = [I - mu(n-1)*u(n-1)*u(n-1)^T]*phi(n-1) + e(n-1)*u(n-1)
        phi_n = (eye(M) - mu_B(n-1)*(u_nm1*u_nm1')) * phi_n_1 + e_nm1*u_nm1;
        phi_B(:, n) = phi_n;
        
        % Step-size update
        mu_B(n+1) = mu_n + rho * e_n * (u_n') * phi_n;
    end
    
    % ------ (c) Ang & Farhang Method ------
    w_A = zeros(M, N+1);
    mu_A = zeros(1, N+1);
    e_A = zeros(1, N+1);
    phi_A = zeros(M, N+1);
    mu_A(M+2) = mu_init;  % Initial step size

    for n = (M+2):N
        u_n = v(n-1);
        d_n = x(n);
        w_n = w_A(:, n);
        mu_n = mu_A(n);
        
        e_n = d_n - w_n' * u_n;
        e_A(n) = e_n;
        
        w_A(:, n+1) = w_n + mu_n * e_n * u_n;
        
        % Update phi
        u_nm1 = v(n-2);
        phi_n_1 = phi_A(:, n-1);
        e_nm1 = e_A(n-1);
        
        % Farhang: phi(n) = alpha*phi(n-1) + e(n-1)*u(n-1)
        phi_n = alpha * phi_n_1 + e_nm1 * u_nm1;
        phi_A(:, n) = phi_n;
        
        mu_A(n+1) = mu_n + rho * e_n * (u_n') * phi_n;
    end
    
    % ------ (d) Matthews Method ------
    w_M = zeros(M, N+1);
    mu_M = zeros(1, N+1);
    e_M = zeros(1, N+1);
    phi_M = zeros(M, N+1);
    mu_M(M+2) = mu_init;

    for n = (M+2):N
        u_n = v(n-1);
        d_n = x(n);
        w_n = w_M(:, n);
        mu_n = mu_M(n);

        e_n = d_n - w_n' * u_n;
        e_M(n) = e_n;
        
        w_M(:, n+1) = w_n + mu_n * e_n * u_n;
        
        % Matthews: phi(n) = e(n-1)*u(n-1)
        u_nm1 = v(n-2);
        e_nm1 = e_M(n-1);
        phi_n = e_nm1 * u_nm1;
        phi_M(:, n) = phi_n;
        
        mu_M(n+1) = mu_n + rho * e_n * (u_n') * phi_n;
    end
    
    % ------ (e) Standard LMS (step-size = 0.01) ------
    w_N = zeros(M, N+1);
    mu_N = zeros(1, N+1);
    e_N = zeros(1, N+1);
    mu_N(M+2) = mu_fixed_list(1);  % First fixed step-size

    for n = (M+2):N
        u_n = v(n-1);
        d_n = x(n);
        w_n = w_N(:, n);
        mu_n_ = mu_N(n);
        
        e_n_ = d_n - w_n' * u_n;
        e_N(n) = e_n_;
        
        w_N(:, n+1) = w_n + mu_n_ * e_n_ * u_n;
        mu_N(n+1) = mu_n_;
    end
    
    % ------ (f) Standard LMS (step-size = 0.1) ------
    w_N_Altered = zeros(M, N+1);
    mu_NA = zeros(1, N+1);
    e_NA = zeros(1, N+1);
    mu_NA(M+2) = mu_fixed_list(2); % Second fixed step-size

    for n = (M+2):N
        u_n = v(n-1);
        d_n = x(n);
        w_n = w_N_Altered(:, n);
        mu_n_ = mu_NA(n);
        
        e_n_ = d_n - w_n' * u_n;
        e_NA(n) = e_n_;
        
        w_N_Altered(:, n+1) = w_n + mu_n_ * e_n_ * u_n;
        mu_NA(n+1) = mu_n_;
    end
    
    % ------ Accumulate results of this trial ------
    w_B_Avg = w_B_Avg + w_B;
    w_A_Avg = w_A_Avg + w_A;
    w_M_Avg = w_M_Avg + w_M;
    w_LMS_Avg_1 = w_LMS_Avg_1 + w_N;
    w_LMA_Avg_2 = w_LMA_Avg_2 + w_N_Altered;
end

%% ========== 4. Average over K Trials ==========
w_B_Avg = w_B_Avg / num_trials;
w_A_Avg = w_A_Avg / num_trials;
w_M_Avg = w_M_Avg / num_trials;
w_LMS_Avg_1 = w_LMS_Avg_1 / num_trials;
w_LMA_Avg_2 = w_LMA_Avg_2 / num_trials;

%% ========== 5. Plot: Compare w(n) with w_true = 0.9 ==========
figure; hold on; grid on;
plot(w_true - w_LMS_Avg_1(1,:), '-b', 'LineWidth', 1);
plot(w_true - w_LMA_Avg_2(1,:), '-r', 'LineWidth', 1);
plot(w_true - w_M_Avg(1,:), '-g', 'LineWidth', 1);
plot(w_true - w_A_Avg(1,:), '-m', 'LineWidth', 1);
plot(w_true - w_B_Avg(1,:), '-c', 'LineWidth', 1);

xlim([0, N]);
legend(['Standard LMS, \mu=' num2str(mu_fixed_list(1))], ...
       ['Standard LMS, \mu=' num2str(mu_fixed_list(2))], ...
       ['Matthews, \mu_{init}=' num2str(mu_init)], ...
       ['Ang & Farhang, \mu_{init}=' num2str(mu_init)], ...
       ['Benveniste, \mu_{init}=' num2str(mu_init)], ...
       'Location','best');
xlabel('Step n');
ylabel('Weight Error = 0.9 - w(n)');
title('Comparison of LMS and GASS (MA(1) system)');
