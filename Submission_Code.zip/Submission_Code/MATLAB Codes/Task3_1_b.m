clc; clear; close all;
addpath('./wind-dataset/');
% Set data filenames
wind_files = {'low-wind.mat', 'medium-wind.mat', 'high-wind.mat'};
wind_labels = {'Low Wind', 'Medium Wind', 'High Wind'};

% Parameter settings
mu = [0.1, 0.01, 0.001]; % Learning rates
M_values = 1:30; % Filter order range
num_trials = 100; % Number of independent experiments (for curve smoothing)

% Preallocate MPSE storage matrices
MPSE_CLMS = zeros(length(M_values), length(wind_files));
MPSE_ACLMS = zeros(length(M_values), length(wind_files));

%% Plot Scatter Diagrams of Wind Speeds
figure;
for w = 1:length(wind_files)
    % Load data
    data = load(wind_files{w});
    v_east = data.v_east; % East wind speed
    v_north = data.v_north; % North wind speed
    v = v_east + 1j * v_north; % Generate complex wind signal
    N = length(v);

    % Plot Circularity Plot
    subplot(1, 3, w);
    scatter(real(v), imag(v), 10, 'b', 'filled');
    grid on;
    xlabel('Real Part (East-West)');
    ylabel('Imaginary Part (North-South)');
    title(['Scatter Plot: ', wind_labels{w}]);
end
set(gcf, 'Position', [100, 100, 1200, 400]);

%% Compute MPSE for different filter orders
for w = 1:length(wind_files)
    % Load data
    data = load(wind_files{w});
    v_east = data.v_east; % East wind speed
    v_north = data.v_north; % North wind speed
    v = v_east + 1j * v_north; % Generate complex wind signal
    N = length(v);
    
    for m_idx = 1:length(M_values)
        M = M_values(m_idx); % Current filter order
        errors_CLMS = zeros(1, N-M);
        errors_ACLMS = zeros(1, N-M);
        
        for i = 1:num_trials
            % CLMS initialization
            h_CLMS = zeros(M, 1);
            error_CLMS = zeros(1, N-M);
            
            % ACLMS initialization
            h_ACLMS = zeros(M, 1);
            g_ACLMS = zeros(M, 1);
            error_ACLMS = zeros(1, N-M);
            
            for n = M+1:N
                x_segment = v(n-1:-1:n-M);
                
                % CLMS prediction
                y_hat_CLMS = h_CLMS' * x_segment;
                error_CLMS(n-M) = v(n) - y_hat_CLMS;
                h_CLMS = h_CLMS + mu(w) * conj(error_CLMS(n-M)) * x_segment;

                % ACLMS prediction
                y_hat_ACLMS = h_ACLMS' * x_segment + g_ACLMS' * conj(x_segment);
                error_ACLMS(n-M) = v(n) - y_hat_ACLMS;
                h_ACLMS = h_ACLMS + mu(w) * conj(error_ACLMS(n-M)) * x_segment;
                g_ACLMS = g_ACLMS + mu(w) * conj(error_ACLMS(n-M)) * conj(x_segment);
            end
            
            % Record squared error
            errors_CLMS = errors_CLMS + abs(error_CLMS).^2;
            errors_ACLMS = errors_ACLMS + abs(error_ACLMS).^2;
        end
        
        % Compute MPSE (Mean Prediction Squared Error)
        MPSE_CLMS(m_idx, w) = pow2db(mean(errors_CLMS / num_trials));
        MPSE_ACLMS(m_idx, w) = pow2db(mean(errors_ACLMS / num_trials));
    end
end

%% Plot MPSE curves
figure;
for w = 1:length(wind_files)
    subplot(1, 3, w);
    plot(M_values, MPSE_CLMS(:, w), 'b', 'LineWidth', 1.5); hold on;
    plot(M_values, MPSE_ACLMS(:, w), 'r', 'LineWidth', 1.5);
    xlabel('Filter order M');
    ylabel('MPSE (dB)');
    title(wind_labels{w});
    legend('CLMS', 'ACLMS');
    grid on;
end
set(gcf, 'Position', [100, 100, 1200, 400]); % Adjust figure size
