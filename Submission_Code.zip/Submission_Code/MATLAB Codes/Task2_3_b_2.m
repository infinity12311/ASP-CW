clc; clear; close all;

% Parameter settings
N = 1000; % Signal length
mu = 0.01; % Learning rate
num_realizations = 100; % Number of experiments
delta = 3; % Fixed delay Δ = 3
M_values = 1:20; % Predictor order M from 1 to 20

% Preallocate MSPE results storage
MSPE_results = zeros(length(M_values), 1);

% Iterate over different M values
for m_idx = 1:length(M_values)
    M = M_values(m_idx);
    MSPE_all = zeros(N, num_realizations); % Store error signals

    for realization = 1:num_realizations
        % Generate signal
        n = (0:N-1)';
        x = sin(0.01 * pi * n); % True signal
        v = randn(N,1); % White noise
        eta = v + 0.5 * [zeros(2,1); v(1:end-2)]; % Colored noise
        s = x + eta; % Noisy signal

        % Adaptive filter initialization
        w = zeros(M,1); % Linear predictor weights
        x_hat = zeros(N,1); % Estimated clean signal
        e = zeros(N,1); % Error signal

        % LMS iteration
        for n = M+delta:N
            u = s(n-delta:-1:n-delta-M+1);
            x_hat(n) = w' * u;
            e(n) = s(n) - x_hat(n);
            w = w + mu * e(n) * u;
        end

        % Store error signal
        MSPE_all(:, realization) = x - x_hat;
    end

    % Compute Mean Squared Prediction Error (MSPE)
    MSPE_results(m_idx) = mean(mean(MSPE_all.^2));
end

% Convert MSPE to dB
MSPE_dB = 10 * log10(MSPE_results);

% Plot MSPE vs Order M
figure;
plot(M_values, MSPE_dB, 'ro-', 'LineWidth', 1.5, 'MarkerSize', 6);

% Set legend and labels
xlabel('Order M');
ylabel('MSPE (dB)');
title('MSPE vs. Filter Order M (Fixed \Delta = 3)');
grid on;
