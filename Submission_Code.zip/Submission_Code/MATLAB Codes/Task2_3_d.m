clc; clear; close all;

%% **Load EEG Data**
load('EEG_Data/EEG_Data_Assignment2.mat'); % Ensure the correct file path

% Select EEG signal channel (can be changed to 'POz')
EEG_raw = Cz; 
fs = fs; % Sampling rate
N = length(EEG_raw); % Signal length
t = (0:N-1)' / fs; % Time vector

% **Parameter Selection**
M_values = [10, 20, 50]; % Three different filter orders
mu_values = [0.001, 0.01, 0.1]; % Three different learning rates

%% **Figure 1: Fixed μ, Compare Different M**
mu_fixed = 0.01; % Fixed learning rate
figure;
tiledlayout(length(M_values), 1); % Create subplot layout

for i = 1:length(M_values)
    M = M_values(i);
    
    % Generate 50Hz reference noise
    reference_noise = sin(2 * pi * 50 * t) + sqrt(0.01) * randn(N, 1); 

    % Initialize ANC filter
    w_ANC = zeros(M,1);
    EEG_cleaned = zeros(N,1);

    % ANC LMS Iteration
    for n = M+1:N
        u_ANC = reference_noise(n:-1:n-M+1);
        noise_estimate = w_ANC' * u_ANC;
        EEG_cleaned(n) = EEG_raw(n) - noise_estimate;
        w_ANC = w_ANC + mu_fixed * EEG_cleaned(n) * u_ANC;
    end

    % Plot spectrogram
    nexttile;
    spectrogram(EEG_cleaned, hamming(1024), 512, 2048, fs, 'yaxis');
    title(['ANC Spectrogram (M=', num2str(M), ', \mu=', num2str(mu_fixed), ')']);
    colorbar;
end

sgtitle('ANC Spectrogram for Different M (Fixed \mu=0.01)');

%% **Figure 2: Fixed M, Compare Different μ**
M_fixed = 20; % Fixed filter order
figure;
tiledlayout(length(mu_values), 1); % Create subplot layout

for i = 1:length(mu_values)
    mu = mu_values(i);
    
    % Generate 50Hz reference noise
    reference_noise = sin(2 * pi * 50 * t) + sqrt(0.01) * randn(N, 1);

    % Initialize ANC filter
    w_ANC = zeros(M_fixed,1);
    EEG_cleaned = zeros(N,1);

    % ANC LMS Iteration
    for n = M_fixed+1:N
        u_ANC = reference_noise(n:-1:n-M_fixed+1);
        noise_estimate = w_ANC' * u_ANC;
        EEG_cleaned(n) = EEG_raw(n) - noise_estimate;
        w_ANC = w_ANC + mu * EEG_cleaned(n) * u_ANC;
    end

    % Plot spectrogram
    nexttile;
    spectrogram(EEG_cleaned, hamming(1024), 512, 2048, fs, 'yaxis');
    title(['ANC Spectrogram (M=', num2str(M_fixed), ', \mu=', num2str(mu), ')']);
    colorbar;
end

sgtitle('ANC Spectrogram for Different \mu (Fixed M=20)');