clc; clear; close all;

% Parameter settings
N = 1000; % Signal length
M = 5; % Predictor order
mu = 0.01; % Learning rate
delta = 3; % Fixed ALE delay
num_realizations = 100; % Number of experiments

% Preallocate storage variables
MSPE_ALE = zeros(num_realizations, 1);
MSPE_ANC = zeros(num_realizations, 1);
x_hat_ALE_all = zeros(N, num_realizations);
x_hat_ANC_all = zeros(N, num_realizations);

% Run multiple experiments
for realization = 1:num_realizations
    % Generate signals
    n = (0:N-1)';
    x = sin(0.01 * pi * n); % True signal
    v = randn(N,1); % White noise
    eta = v + 0.5 * [zeros(2,1); v(1:end-2)]; % Colored noise
    s = x + eta; % Noisy signal
    
    % ========== Adaptive Line Enhancer (ALE) ==========
    w_ALE = zeros(M,1); % ALE linear predictor weights
    x_hat_ALE = zeros(N,1); % Estimated clean signal
    e_ALE = zeros(N,1); % Error signal

    % ALE LMS iteration
    for n = M+delta:N
        u_ALE = s(n-delta:-1:n-delta-M+1);
        x_hat_ALE(n) = w_ALE' * u_ALE;
        e_ALE(n) = s(n) - x_hat_ALE(n);
        w_ALE = w_ALE + mu * e_ALE(n) * u_ALE;
    end

    % ========== Adaptive Noise Cancellation (ANC) ==========
    e_secondary = v; % ANC reference noise input
    w_ANC = zeros(M,1); % ANC linear predictor weights
    x_hat_ANC = zeros(N,1); % Estimated clean signal

    % ANC LMS iteration
    for n = M+1:N
        u_ANC = e_secondary(n:-1:n-M+1);
        eta_hat = w_ANC' * u_ANC;
        x_hat_ANC(n) = s(n) - eta_hat;
        w_ANC = w_ANC + mu * x_hat_ANC(n) * u_ANC;
    end

    % Store the results of the current experiment
    x_hat_ALE_all(:, realization) = x_hat_ALE;
    x_hat_ANC_all(:, realization) = x_hat_ANC;

    % Compute MSPE
    MSPE_ALE(realization) = mean((x - x_hat_ALE).^2);
    MSPE_ANC(realization) = mean((x - x_hat_ANC).^2);
end

% Compute average MSPE
MSPE_ALE_mean = mean(MSPE_ALE);
MSPE_ANC_mean = mean(MSPE_ANC);

% Compute the mean of 100 realizations
x_hat_ALE_mean = mean(x_hat_ALE_all, 2);
x_hat_ANC_mean = mean(x_hat_ANC_all, 2);

% Convert MSPE to dB
MSPE_ALE_dB = 10 * log10(MSPE_ALE_mean);
MSPE_ANC_dB = 10 * log10(MSPE_ANC_mean);

% Display MSPE results
fprintf('ALE MSPE (dB): %.2f dB\n', MSPE_ALE_dB);
fprintf('ANC MSPE (dB): %.2f dB\n', MSPE_ANC_dB);

% ====== Plot Results in a Single Figure ======
figure;
plot(x, 'k', 'LineWidth', 2, 'DisplayName', 'True signal x(n)'); % True signal
hold on;
plot(x_hat_ALE_mean, 'b', 'LineWidth', 1.5, 'DisplayName', 'ALE Recovered Signal');
plot(x_hat_ANC_mean, 'r', 'LineWidth', 1.5, 'DisplayName', 'ANC Recovered Signal');
legend('show');
xlabel('Sample index n');
ylabel('Amplitude');
title('Comparison of True Signal, ALE and ANC Recovered Signals');
grid on;
