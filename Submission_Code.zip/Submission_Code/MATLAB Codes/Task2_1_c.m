%% ========== 0. Parameters and Initialization ==========
clear; clc; close all;

% AR(2) coefficients (as given in the assignment)
a1 = 0.1; 
a2 = 0.8; 
sigma2_eta = 0.25;  % Noise variance

% Order of the filter to estimate (predictor: x(n-1), x(n-2))
M = 2;

% Two step-sizes (can be modified or added)
mu_list = [0.05, 0.01];

% Other settings
N = 1000;               % Data length per trial
numReal = 100;          % Number of repeated trials
steadyStateStart = 600; % Starting point of steady-state region (can be adjusted)

% Theoretical autocorrelation matrix R (from Yule-Walker or lecture notes)
% Here directly using known values: r(0)=0.9259, r(1)=0.4629
r0 = 0.9259; 
r1 = 0.4629;
R_theory = [r0 r1; r1 r0];
traceR = trace(R_theory);

%% ========== Array to store error ==========
% e2_all(mu_idx, realization, n)
e2_all = zeros(length(mu_list), numReal, N);

%% ========== 1. Run multiple trials, record instantaneous squared error ==========
for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);
    
    for realization = 1:numReal
        % --- (a) Generate AR(2) data ---
        w_noise = sqrt(sigma2_eta)*randn(N,1);  
        x = zeros(N,1);
        x(1)=0; x(2)=0;  % Initial values
        for n=3:N
            x(n) = a1*x(n-1) + a2*x(n-2) + w_noise(n);
        end

        % --- (b) LMS initialization ---
        wLMS = zeros(M,1);  % Weight vector [w1; w2]
        e_save = zeros(N,1);

        % --- (c) Online update, point-by-point, record error ---
        for n=3:N
            u = [x(n-1); x(n-2)];
            x_hat = wLMS' * u;
            e_n = x(n) - x_hat;
            e_save(n) = e_n;

            % LMS update
            wLMS = wLMS + mu * e_n * u;
        end

        % --- (d) Store instantaneous squared error ---
        e2_all(mu_idx, realization, :) = e_save.^2;
    end
end

%% ========== 2. For each step-size, compute learning curve (ensemble average) and estimate misadjustment ==========
% For demonstration, we output for each step-size:
% 1) Steady-state MSE
% 2) EMSE = MSE - sigma2_eta
% 3) misadjustment M = EMSE / sigma2_eta
% 4) Theoretical approximate misadjustment = (mu/2)*trace(R)

for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);

    % --- (a) Average over numReal trials at each n -> get e2_ens(n)
    e2_ens = mean( squeeze(e2_all(mu_idx,:,:)), 1 );  % (1 x N)

    % --- (b) Time average over the steady-state region (e.g. n = 600~1000)
    e2_ss = mean(e2_ens(steadyStateStart:end));  % Steady-state MSE

    % --- (c) Compute experimental MSE, EMSE, misadjustment
    MSE_ss = e2_ss;                       % Steady-state MSE
    EMSE = MSE_ss - sigma2_eta;          % Excess MSE
    M_est = EMSE / sigma2_eta;           % Experimentally estimated misadjustment

    % --- (d) Theoretical approximate misadjustment (for small step-size)
    M_theory = (mu/2)*traceR;

    % --- (e) Output results ---
    fprintf('\n=== Results for step-size mu = %.3f ===\n', mu);
    fprintf('Steady-state MSE (exp)      = %.4f\n', MSE_ss);
    fprintf('Excess MSE (EMSE)           = %.4f\n', EMSE);
    fprintf('Estimated misadjustment M   = %.4f\n', M_est);
    fprintf('Theoretical misadjustment   = %.4f\n', M_theory);
    fprintf('Absolute difference         = %.4f\n', abs(M_theory-M_est));
end
