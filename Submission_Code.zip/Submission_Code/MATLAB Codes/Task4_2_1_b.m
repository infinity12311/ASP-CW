clear; clc; close all;
% Generate time series
t = ((2*pi)/100):((2*pi)/100):10*pi; 

% Generate reference signals y1, y2, y3
y1 = sin(t);      % Frequency 1
y2 = sin(0.5*t);  % Lower frequency
y3 = sin(4*t);    % Higher frequency

% Generate test signal to classify (can be modified)
y_test = sin(4*t); % Testing y3 here; you can change to y1 or y2

% Compute convolution of input signal y_test with y1, y2, y3
conv_y1 = conv(y_test, y1, 'same');
conv_y2 = conv(y_test, y2, 'same');
conv_y3 = conv(y_test, y3, 'same');

% Extract features from convolution results
feature_mean = [mean(abs(conv_y1)), mean(abs(conv_y2)), mean(abs(conv_y3))]; % Mean of absolute values
feature_max = [max(abs(conv_y1)), max(abs(conv_y2)), max(abs(conv_y3))];     % Maximum peak

% Compute final matching scores (you may adjust weights)
score = feature_mean + feature_max;

% Find the class with the highest score
[~, predicted_class] = max(score);

% Output predicted result
fprintf('Predicted Signal: y%d\n', predicted_class);

% Plotting: show y_test and its convolution results with y1, y2, y3
figure;

% Original test signal
subplot(4,1,1);
plot(t, y_test, 'k');
title('Test Signal');
xlabel('Time');
ylabel('Amplitude');
grid on;

% Convolution of y_test with y1
subplot(4,1,2);
plot(t, conv_y1, 'b');
title('Convolution with y1');
xlabel('Time');
ylabel('Amplitude');
grid on;

% Convolution of y_test with y2
subplot(4,1,3);
plot(t, conv_y2, 'r');
title('Convolution with y2');
xlabel('Time');
ylabel('Amplitude');
grid on;

% Convolution of y_test with y3
subplot(4,1,4);
plot(t, conv_y3, 'g');
title('Convolution with y3');
xlabel('Time');
ylabel('Amplitude');
grid on;
