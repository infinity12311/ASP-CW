clc; clear; close all;

% Parameter settings
N = 1000; % Signal length
mu = 0.01; % Learning rate
num_realizations = 100; % Number of experiments
delta_values = 3:25; % Different delays Δ
M_values = [5, 10, 15, 20]; % Different predictor orders M
num_deltas = length(delta_values);
num_M = length(M_values);

% Preallocate MSPE results storage
MSPE_results = zeros(num_deltas, num_M);

% Iterate over different M values
for m_idx = 1:num_M
    M = M_values(m_idx);
    
    % Iterate over different delta values
    for d_idx = 1:num_deltas
        delta = delta_values(d_idx);
        MSPE_all = zeros(N, num_realizations); % Store error signals
        
        for realization = 1:num_realizations
            % Generate signal
            n = (0:N-1)';
            x = sin(0.01 * pi * n); % True signal
            v = randn(N,1); % White noise
            eta = v + 0.5 * [zeros(2,1); v(1:end-2)]; % Colored noise
            s = x + eta; % Noisy signal
            
            % Adaptive filter initialization
            w = zeros(M,1); % Linear predictor weights
            x_hat = zeros(N,1); % Estimated clean signal
            e = zeros(N,1); % Error signal

            % LMS iteration
            for n = M+delta:N
                u = s(n-delta:-1:n-delta-M+1);
                x_hat(n) = w' * u;
                e(n) = s(n) - x_hat(n);
                w = w + mu * e(n) * u;
            end
            
            % Store error signal
            MSPE_all(:, realization) = x-x_hat;
        end

        % Compute Mean Squared Prediction Error (MSPE)
        MSPE_results(d_idx, m_idx) = mean(mean(MSPE_all.^2));
    end
end

% Convert MSPE to dB
MSPE_dB = 10 * log10(MSPE_results);

% Plot MSPE vs Delay
figure;
hold on;
colors = lines(num_M); % Generate color palette
markers = {'o', 's', '^', 'd'}; % Marker styles

for m_idx = 1:num_M
    plot(delta_values, MSPE_dB(:, m_idx), ...
        'Color', colors(m_idx, :), 'LineWidth', 1.5, ...
        'Marker', markers{m_idx}, 'MarkerSize', 6, ...
        'DisplayName', ['M = ', num2str(M_values(m_idx))]);
end

% Set legend and labels
legend('show', 'Location', 'northwest');
xlabel('Delay \Delta');
ylabel('MSPE (dB)');
title('MSPE of specific filter orders against delays');
grid on;
hold off;
