clc; clear; close all;
addpath('./EEG_Data/');

%% ========== 1. Load EEG data and select a segment (length 1200) ==========
% Assume 'EEG_Data_Assignment1.mat' exists in current folder with variables POz, fs
data = load('EEG_Data_Assignment1.mat');  % should contain POz, fs
POz_all = data.POz;  % EEG signal
fs = data.fs;        % Sampling frequency, e.g. 1200 Hz

N = 1200;      % Segment length
a = 60000;     % Starting position of segment (can be modified)
y = POz_all(a : a+N-1).';  % Convert to row vector (1×N) for processing

%% ========== 2. Define DFT-CLMS input vector x(n) ==========
% Refer to Eq. (41) from 3.3(c), construct for length N:
%   x(n) = (1/N)* [1, e^{j2πn/N}, e^{j4πn/N}, ..., e^{j2π(N-1)n/N}]^T
% where n = 0,1,...,N-1
M = N;  % Input vector dimension = N
xFun = @(n) (1/N)*exp(1j*2*pi*(0:M-1)*n/N).';  % Returns M×1 column vector

%% ========== 3. Initialize DFT-CLMS parameters ==========
mu = 1;               % Based on Widrow et al., DFT-CLMS typically uses mu = 1
wMat = zeros(M, N+1); % Store weight vectors at each time (M×(N+1))
e = zeros(1, N);      % Error storage

%% ========== 4. Perform DFT-CLMS online iteration ==========
for n = 1:N
    x_n = xFun(n-1);            % Input vector at time n, index n-1 used in exponent
    y_hat = wMat(:,n)' * x_n;   % Predicted output
    e(n) = y(n) - y_hat;        % Error
    wMat(:,n+1) = wMat(:,n) + mu * conj(e(n)) * x_n;  % Update weights
end

%% ========== 5. Plot Time-Frequency Diagram (|w(k,n)|) ==========
% wMat(k,n) represents coefficient on the k-th "frequency" at iteration n-1
% Take wMat(:,2:end) to represent updates from iteration 1 to N
W_mag = abs(wMat(:, 2:end));  % Size M×N

% Frequency axis: k=0~(M-1) => freq_k = (k * fs)/N
freqAxis = (0:M-1)*(fs/N);
timeAxis = 1:N;

figure;
imagesc(timeAxis, freqAxis, W_mag);
axis xy;  % Make frequency axis go from low to high
xlabel('Time index (sample)');
ylabel('Frequency (Hz)');
title('DFT-CLMS Time-Frequency Diagram of EEG Segment');
colorbar;
colormap jet;
ylim([0,60])
