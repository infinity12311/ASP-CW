function [acf, k] = fACF(x, type)
    N = length(x); % 信号长度
    
    % **Step 1: 扩展信号 (Padding)**
    x_zp = zeros(3*N,1); 
    x_zp(N+1:2*N) = x; % 在中间填充信号
    
    % **Step 3: 选择 ACF 计算方式**
    switch lower(type)
        case 'biased'
            k = -(N-1) : (N-1);
            k = k';
            acf = zeros(length(k),1);
            for i = 1:length(k)
                acf(i) = 1/N * sum(x_zp .* circshift(x_zp, k(i)));
            end
            
        case 'unbiased'
            k = 0: (N-1);
            k = k';
            acf = zeros(length(k),1);
            for i = 1:length(k)
                acf(i) = 1/(N-k(i)) * sum(x_zp .* circshift(x_zp, k(i)));
            end   
            
        otherwise
            error('Invalid type. Choose ''biased'' or ''unbiased''.');
    end
end



