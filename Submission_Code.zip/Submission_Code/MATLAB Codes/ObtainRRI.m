clc; clear; close all;
addpath('./Function/');
RAW_ECG = readmatrix("ECG_Data.xlsx");

data = RAW_ECG(:,2);

figure
plot(data)
trial1 = data(1:128584);
trial2 = data(131232:253781);
trial3 = data(256850:end);
[xRRI1,fsRRI1] = ECG_to_RRI(trial1,500,'ampthresh', 1.85*10e-5,'anomalyparam',10);

[xRRI2,fsRRI2] = ECG_to_RRI(trial2,500,'ampthresh', 1.85*10e-5,'anomalyparam',10);

[xRRI3,fsRRI3] = ECG_to_RRI(trial3,500,'ampthresh', 1.85*10e-5,'anomalyparam',10);

save('RRI_data.mat', 'xRRI1', 'fsRRI1', 'xRRI2', 'fsRRI2', 'xRRI3', 'fsRRI3');