clc; clear; close all;

% Parameter settings
N = 1500;       % Signal length
fs = 1000;      % Sampling frequency
mu = 0.1;       % CLMS learning rate
sigma_eta = sqrt(0.05);  % Noise standard deviation

% Generate frequency variation f(n)
f = zeros(1, N);
for n = 1:N
    if n <= 500
        f(n) = 100;
    elseif n <= 1000
        f(n) = 100 + (n - 500) / 2;
    else
        f(n) = 100 + ((n - 1000) / 25).^2;
    end
end

% Compute phase phi(n) = cumulative sum of f(n)
phi = cumsum(f) * (2 * pi / fs);

% Generate FM signal y(n) = exp(j*phi(n)) + eta(n)
eta = (randn(1, N) + 1j * randn(1, N)) * sigma_eta / sqrt(2);
y = exp(1j * phi) + eta;

% Initialize CLMS parameters
order = 1; % AR(1) model
h_CLMS = zeros(order, N); % CLMS weights
error_CLMS = zeros(1, N); % Error storage
H = zeros(1024, N); % Instantaneous power spectrum matrix

% CLMS iteration to compute AR(1) coefficients and instantaneous PSD
for n = 2:N
    x_segment = y(n-1); % Use only the previous sample
    y_hat_CLMS = h_CLMS(n-1)' * x_segment; % Predicted output
    error_CLMS(n) = y(n) - y_hat_CLMS; % Error calculation
    h_CLMS(n) = h_CLMS(n-1) + mu * conj(error_CLMS(n)) * x_segment; % Update weight

    % Compute instantaneous power spectrum
    [h, w] = freqz(1, [1, -conj(h_CLMS(n))], 1024, fs);
    H(:, n) = abs(h).^2;
end

% Process power spectrum data, remove outliers
medianH = 50 * median(median(H));
H(H > medianH) = medianH;

% Plot time-frequency spectrum
figure;
imagesc(1:N, w, 10*log10(H));
axis xy;
xlabel('Time Index n');
ylabel('Frequency (Hz)');
title('Time-Frequency Spectrum using CLMS');
colorbar;
colormap jet;
