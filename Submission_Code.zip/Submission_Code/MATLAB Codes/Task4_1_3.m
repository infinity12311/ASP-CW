clear; clc; close all;
% Load data
load('time-series.mat'); % Assume variable y is stored here
y = y(:); % Ensure y is a column vector
N = length(y); % Number of samples

% Remove mean
y_mean = mean(y);
y_zero_mean = y - y_mean;

% Initialize parameters
mu = 1e-5; % Learning rate
order = 4; % AR(4) prediction model
w = zeros(order, 1); % Initialize weights
y_pred = zeros(N, 1); % Predicted output
e = zeros(N, 1); % Error signal

% Choose value of a (recommended range: 0.5 to 2)
a = 82; % You can adjust this value, e.g., a = 0.5, 1, 1.5, 2 for comparison

% Use a * tanh as activation function
for n = order+1:N
    x_n = y_zero_mean(n-1:-1:n-order); % Use y[n-1] to y[n-4] as input
    y_pred(n) = a * tanh(w' * x_n); % Prediction (nonlinear activation with scaling factor)
    e(n) = y_zero_mean(n) - y_pred(n); % Error calculation
    w = w + mu * e(n) * x_n; % LMS weight update
end

% Compute Mean Squared Error (MSE) and Prediction Gain (Rp)
sigma_yhat2 = var(y_pred); % Variance of predicted signal y
sigma_e2 = var(e); % Variance of prediction error
Rp = 10 * log10(sigma_yhat2 / sigma_e2); % Prediction gain (dB)

% Plot results
figure;
plot(y_zero_mean, 'b', 'DisplayName', 'Zero-mean y[n]');
hold on;
plot(y_pred, 'r--', 'DisplayName', ['Predicted y[n] with a * tanh, a = ' num2str(a)]);
legend;
xlabel('Sample Index');
ylabel('Amplitude');
title(['Scaled Activation LMS Prediction: MSE = ', num2str(sigma_e2), ', Rp = ', num2str(Rp), ' dB']);
grid on;
hold off;
