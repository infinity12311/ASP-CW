clear; clc; close all;
% Generate time series
t = ((2*pi)/100):((2*pi)/100):10*pi; 

% Generate sine signals of different frequencies
y1 = sin(t);      % Frequency = 1
y2 = sin(0.5*t);  % Lower frequency
y3 = sin(4*t);    % Higher frequency

% Compute convolutions
auto_conv_y1 = conv(y1, y1, 'same'); % Auto-convolution of y1
conv_y1_y2 = conv(y1, y2, 'same');   % Convolution of y1 with y2
conv_y1_y3 = conv(y1, y3, 'same');   % Convolution of y1 with y3

% Plotting
figure;

% Auto-convolution y1 * y1
subplot(3,1,1);
plot(t, auto_conv_y1, 'b');
title('Auto-convolution of y1');
xlabel('Time');
ylabel('Amplitude');
grid on;

% Convolution y1 * y2
subplot(3,1,2);
plot(t, conv_y1_y2, 'r');
title('Convolution of y1 with y2');
xlabel('Time');
ylabel('Amplitude');
grid on;

% Convolution y1 * y3
subplot(3,1,3);
plot(t, conv_y1_y3, 'g');
title('Convolution of y1 with y3');
xlabel('Time');
ylabel('Amplitude');
grid on;
