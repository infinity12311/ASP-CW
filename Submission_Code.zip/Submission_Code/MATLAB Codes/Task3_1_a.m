clc; clear; close all;

% Parameter settings
mu = 0.01;  % Learning rate
b1 = 1.5 + 1j;
b2 = 2.5 - 0.5j;
num_trials = 100; % Perform 100 independent experiments to obtain a smooth learning curve
N = 1000; % Number of samples
M = 1; % Filter order

% Preallocate error storage variables
errors_CLMS = zeros(1, N);
errors_ACLMS = zeros(1, N);

% Perform multiple experiments to compute average learning curve
for i = 1:num_trials
    % Generate input signal (circular complex Gaussian white noise)
    x = (randn(N+1, 1) + 1j * randn(N+1, 1)) / sqrt(2);

    % Generate WLMA(1) process
    y = zeros(N+1, 1);
    for n = 2:N+1
        y(n) = x(n) + b1 * x(n-1) + b2 * conj(x(n-1));
    end

    % CLMS computation
    h = zeros(M, 1); % CLMS filter coefficient initialization
    error_CLMS = zeros(1, N);
    for n = M+1:N+1
        x_segment = x(n-1:-1:n-M); % Input data segment
        y_hat = h' * x_segment; % Predicted output
        error_CLMS(n-M) = y(n) - y_hat; % Error computation
        h = h + mu * conj(error_CLMS(n-M)) * x_segment; % Update weights
    end

    % ACLMS computation
    h_a = zeros(M, 1); % ACLMS h filter coefficients
    g_a = zeros(M, 1); % ACLMS g filter coefficients
    error_ACLMS = zeros(1, N);
    for n = M+1:N+1
        x_segment = x(n-1:-1:n-M); % Input data segment
        y_hat_A = h_a' * x_segment + g_a' * conj(x_segment); % Predicted output
        error_ACLMS(n-M) = y(n) - y_hat_A; % Error computation
        h_a = h_a + mu * conj(error_ACLMS(n-M)) * x_segment; % Update h
        g_a = g_a + mu * conj(error_ACLMS(n-M)) * conj(x_segment); % Update g
    end

    % Record squared errors
    errors_CLMS = errors_CLMS + abs(error_CLMS).^2;
    errors_ACLMS = errors_ACLMS + abs(error_ACLMS).^2;
end

% Compute learning curves (log scale)
errors_CLMS_avg = pow2db(errors_CLMS / num_trials);
errors_ACLMS_avg = pow2db(errors_ACLMS / num_trials);

% Plot learning curves
figure;
plot(errors_ACLMS_avg, '-b', 'LineWidth', 1.5); hold on;
plot(errors_CLMS_avg, '-r', 'LineWidth', 1.5);
grid on;
xlabel('Iteration', 'FontSize', 12);
ylabel('10log|e(n)|^2 (dB)', 'FontSize', 12);
title('Learning Curve: CLMS vs ACLMS', 'FontSize', 14);
legend('ACLMS', 'CLMS', 'FontSize', 12);
set(gcf, 'Position', [100, 100, 800, 600]);
