clc; clear; close all;

%% ========== 1. Generate FM Signal (same as section 3.2) ==========
N = 1500;        % Signal length
fs = 1000;       % Sampling frequency
sigma2 = 0.05;   % Noise variance
mu = 1;          % DFT-CLMS learning rate (based on Widrow et al.)

% (a) Construct instantaneous frequency f(n)
f = zeros(1, N);
for n = 1:N
    if n <= 500
        f(n) = 100;
    elseif n <= 1000
        f(n) = 100 + (n - 500)/2;
    else
        f(n) = 100 + ((n - 1000)/25)^2;
    end
end

% (b) Compute phase phi(n) = \sum f(n)*(2π/fs)
phi = cumsum(f) * (2*pi/fs);

% (c) Generate FM signal y(n) = exp(j*phi(n)) + noise
eta = sqrt(sigma2/2) * (randn(1, N) + 1j*randn(1, N));
y = exp(1j * phi) + eta;

%% ========== 2. Construct input vector x(n) for DFT-CLMS ==========
% According to Eq. (41): x(n) = (1/N)*[1, e^{j2πn/N}, ..., e^{j2π(N-1)n/N}]^T
% Note: Whether the 1/N factor is placed in x(n) or weights w(n) varies in literature;
% here we follow Eq. (41) and include it in x(n)
M = N;  % Input vector dimension = N
xFun = @(n) (1/N)*exp(1j*2*pi*(0:M-1)*n/N).';  % Returns M×1 column vector

%% ========== 3. Initialize DFT-CLMS Parameters ==========
wMat = zeros(M, N+1);  % Each time step n has an M-length weight vector
e = zeros(1, N);       % Error vector
% Initial weights are set to 0 (as per Widrow et al.: starting from w(0)=0 with mu=1 converges to DFT solution)

%% ========== 4. Perform DFT-CLMS Iteration ==========
for n = 1:N
    x_n = xFun(n-1);           % Note: time n corresponds to y(n), but exponent uses n-1 to stay consistent
    y_hat = wMat(:, n)' * x_n;  % Predicted output
    e(n) = y(n) - y_hat;        % Error
    % Update weights
    wMat(:, n+1) = wMat(:, n) + mu * conj(e(n)) * x_n;
end

%% ========== 5. Plot Time-Frequency Diagram (|w(k,n)|) ==========
% wMat(k,n) represents the weight on the k-th "frequency" after the n-th iteration
% We only plot values after 1 to N iterations, i.e., wMat(:,2:N+1)
W_mag = abs(wMat(:,2:end));  % Size M×N

% Frequency index: k=0~N-1 => actual frequency freq_k = (k*fs)/N
freqAxis = (0:M-1)*(fs/N);
timeAxis = 1:N;  % Discrete time

figure;
imagesc(timeAxis, freqAxis, W_mag);
axis xy;  % Make frequency axis go from low to high
xlabel('Time index n');
ylabel('Frequency (Hz)');
title('Time-Frequency Diagram (Magnitude of w(k,n)) - DFT-CLMS');
colorbar;
colormap jet;
