% ============ 1. Parameter Settings ================
clear; clc; close all;

N = 10000;              % Total length
a1 = 0.1; a2 = 0.8;     % AR(2) coefficients
sigma2 = 0.25;          % Noise variance
w = sqrt(sigma2)*randn(N,1);  % White noise

% ============ 2. Generate AR(2) Data ================
x = zeros(N,1);
% Given initial values (can be zero), then use recursion
x(1) = 0;
x(2) = 0;
for n = 3:N
    x(n) = a1*x(n-1) + a2*x(n-2) + w(n);
end

% Discard the first 500 samples to remove initial state effects
x = x(501:end);
N_new = length(x);

% ============ 3. Construct Input Matrix and Estimate R =========
% For n = 3 to N_new, let input vector x_in(n) = [x(n-1); x(n-2)]
% For simplicity, construct with matrix operations:
X = [ x(2:end), x(1:end-1) ];  % Size (N_new-1) x 2
R_est = (X'*X) / (N_new-1);    % Estimate autocorrelation matrix using time average

disp('--- Estimated autocorrelation matrix R_est from numerical simulation ---');
disp(R_est);

% ============ 4. Theoretical Matrix and Maximum Eigenvalue =========
% (a) Theoretically derived R
r0 = 0.9259;
r1 = 0.4629;
R_theory = [r0, r1; r1, r0];

disp('--- Theoretically derived autocorrelation matrix R_theory ---');
disp(R_theory);

% (b) Compute maximum eigenvalue of R_est
eigvals_est = eig(R_est);
lambda_max_est = max(eigvals_est);
mu_upper_est = 2 / lambda_max_est;

disp('--- Step size stability range from estimated R_est ---');
disp(['0 < mu < ', num2str(mu_upper_est)]);

% (c) Alternatively, compute maximum eigenvalue of R_theory
eigvals_th = eig(R_theory);
lambda_max_th = max(eigvals_th);
mu_upper_th = 2 / lambda_max_th;

disp('--- Step size stability range from theoretical R_theory ---');
disp(['0 < mu < ', num2str(mu_upper_th)]);
