clear; clc; close all;

%% ========== Parameters and Initialization ==========
% AR(2) coefficients
a1 = 0.1; 
a2 = 0.8; 
sigma2_eta = 0.25;  % Noise variance

% Leaky LMS related
mu_list = [0.01, 0.05];  % Different learning rates
gamma_list = [0.01, 0.1, 0.5];  % Different leakage factors
M = 2;              % Predictor order
N = 1500;           % Data length
numReal = 50;       % Number of trials

% Store the full weight trajectories of all trials
w_history_all = zeros(length(mu_list), length(gamma_list), numReal, M, N);

%% ========== 1. Run multiple trials, compute Leaky LMS coefficient trajectories ==========
for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);
    
    for g_idx = 1:length(gamma_list)
        gamma = gamma_list(g_idx);

        for realization = 1:numReal
            % --- Generate AR(2) data ---
            w_noise = sqrt(sigma2_eta)*randn(N,1);
            x = zeros(N,1);
            x(1)=0; x(2)=0; % Initial values
            for n = 3:N
                x(n) = a1*x(n-1) + a2*x(n-2) + w_noise(n);
            end

            % --- Initialize filter ---
            wLeaky = zeros(M,1);  

            % --- Point-by-point update (Leaky LMS) ---
            for n = 3:N
                u_n = [x(n-1); x(n-2)];
                x_hat = wLeaky' * u_n;
                e_n = x(n) - x_hat;

                % Leaky LMS update:
                wLeaky = (1 - mu*gamma) * wLeaky + mu * e_n * u_n;

                % Record weight at current time step
                w_history_all(mu_idx, g_idx, realization, :, n) = wLeaky;
            end
        end
    end
end

%% ========== 2. Plot coefficient trajectories of all trials ==========
figure;
tiledlayout(length(mu_list), length(gamma_list));

time_axis = 1:N; % Time steps

for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);
    
    for g_idx = 1:length(gamma_list)
        gamma = gamma_list(g_idx);
        
        % Plot
        nexttile;
        hold on;
        
        % Loop through all trials and plot all trajectories
        for realization = 1:numReal
            w1_traj = squeeze(w_history_all(mu_idx, g_idx, realization, 1, :));
            w2_traj = squeeze(w_history_all(mu_idx, g_idx, realization, 2, :));

            plot(time_axis, w1_traj, 'b', 'LineWidth', 0.5, 'HandleVisibility', 'off', 'Color', [0 0 1 0.1]); % Transparent blue
            plot(time_axis, w2_traj, 'r', 'LineWidth', 0.5, 'HandleVisibility', 'off', 'Color', [1 0 0 0.1]); % Transparent red
        end

        % Add representative curves for legend
        h1 = plot(time_axis, squeeze(mean(w_history_all(mu_idx, g_idx, :, 1, :), 3)), 'b', 'LineWidth', 1.5, 'DisplayName', 'Esta_1');
        h2 = plot(time_axis, squeeze(mean(w_history_all(mu_idx, g_idx, :, 2, :), 3)), 'r', 'LineWidth', 1.5, 'DisplayName', 'Esta_2');

        % Reference lines for true coefficients
        h3 = yline(a1, '-b', 'LineWidth', 3, 'DisplayName', 'a_1');
        h4 = yline(a2, '-r', 'LineWidth', 3, 'DisplayName', 'a_2');

        % Set title and labels
        title(['Leaky LMS (\mu = ', num2str(mu), ', \gamma = ', num2str(gamma), ')']);
        xlabel('Time Step');
        ylabel('Estimate');
        
        % Add legend only in the first subplot to avoid repetition
        legend([h1, h2, h3, h4]);
        
        hold off;
    end
end

sgtitle('Leaky LMS Coefficient Estimation for Different \mu and \gamma');
