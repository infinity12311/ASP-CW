%% ========== Parameters and Initialization ==========
clear; clc; close all;

% AR(2) coefficients and noise variance
a1 = 0.1; 
a2 = 0.8; 
sigma2 = 0.25;

% LMS-related
mu_list = [0.05, 0.01];  % Two step-sizes to compare
M = 2;                  % Predictor order (using x(n-1), x(n-2))
N = 1000;               % Data length per trial
numRealization = 100;   % Number of repeated trials

% Preallocate for storing learning curves
% err_store(mu_idx, realization, n)
err_store = zeros(length(mu_list), numRealization, N);

%% ========== 1. Loop over different step-sizes and multiple trials ==========
for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);

    for realization = 1:numRealization
        % ===== (a) Generate AR(2) Data =====
        w = sqrt(sigma2)*randn(N,1);  % White noise
        x = zeros(N,1);
        x(1) = 0; x(2) = 0;           % Initial values can be set arbitrarily
        for n = 3:N
            x(n) = a1*x(n-1) + a2*x(n-2) + w(n);
        end

        % ===== (b) LMS Initialization =====
        wLMS = zeros(M,1);           % Weight vector [w1, w2]^T
        e_save = zeros(N,1);         % Store error at each iteration

        % ===== (c) Point-wise online learning =====
        for n = 3:N
            % Input vector u(n) = [x(n-1); x(n-2)]
            u = [x(n-1); x(n-2)];
            % Predicted output
            x_hat = wLMS'*u;
            % Error
            e_n = x(n) - x_hat;
            e_save(n) = e_n;   % Save error at iteration n

            % LMS update
            wLMS = wLMS + mu * e_n * u;
        end

        % ===== (d) Store instantaneous squared error =====
        err_store(mu_idx, realization, :) = e_save.^2;
    end
end

%% ========== 2. Plot: Two subplots comparing results of different mu ==========
figure;

% ========== (A) Compare single realization (e.g., the first trial) ==========
subplot(1,2,1);
hold on; grid on;
title('Single realisaiton');
xlabel('Iteration (n)'); ylabel('Squared error (dB)');

% mu=0.05, first trial
err_single_mu1 = squeeze(err_store(1,1,:)); % (N x 1)
plot(10*log10(err_single_mu1),'b','LineWidth',1.5);

% mu=0.01, first trial
err_single_mu2 = squeeze(err_store(2,1,:));
plot(10*log10(err_single_mu2),'r','LineWidth',1.5);

legend('\mu=0.05 (single run)','\mu=0.01 (single run)');

% ========== (B) Compare average learning curves over 100 trials ==========
subplot(1,2,2);
hold on; grid on;
title('Average over 100 realisaitons');
xlabel('Iteration (n)'); ylabel('Squared error (dB)');

% mu=0.05, average curve
mean_err_mu1 = mean( squeeze(err_store(1,:,:)), 1 ); % (1 x N)
plot(10*log10(mean_err_mu1),'b','LineWidth',1.5);

% mu=0.01, average curve
mean_err_mu2 = mean( squeeze(err_store(2,:,:)), 1 ); % (1 x N)
plot(10*log10(mean_err_mu2),'r','LineWidth',1.5);

legend('\mu=0.05 (avg)','\mu=0.01 (avg)');
