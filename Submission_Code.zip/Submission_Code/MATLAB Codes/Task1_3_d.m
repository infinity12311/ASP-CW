clc; clear; close all;

%% **Step 1: Set Signal Parameters**
fs = 1; % Sampling frequency (unit: Hz)
nfft = 512; % Number of FFT points
num_samples_list = [30, 60, 120, 240]; % Different sample sizes
frequencies = [0.3, 0.32]; % Target frequencies
noise_variance = 0.2; % Noise variance

figure;
for i = 1:length(num_samples_list)
    N = num_samples_list(i); % Select the current sample size
    n = (0:N-1); % Sample points

    % **Step 2: Generate Complex Exponential Signal**
    noise = 0.3/sqrt(2) * (randn(size(n)) + 1j * randn(size(n))); % Complex Gaussian noise
    x = exp(1j * 2 * pi * frequencies(1) * n) + exp(1j * 2 * pi * frequencies(2) * n) + noise;

    % **Step 3: Compute Periodogram**
    [pxx, f] = periodogram(x, rectwin(length(x)), nfft, fs);

    % **Step 4: Plot PSD for Different Sample Sizes**
    subplot(2,2,i);
    plot(f * 1000, 10*log10(pxx), 'b', 'LineWidth', 1.5); % Convert frequency unit to mHz
    grid on;
    xlabel('Frequency (mHz)'); % Modify unit
    ylabel('Power/frequency (dB/Hz)');
    title(['Periodogram with ', num2str(N), ' samples']);
end
