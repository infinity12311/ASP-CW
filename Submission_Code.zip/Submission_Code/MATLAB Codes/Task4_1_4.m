clear; clc; close all;
% Load data
load('time-series.mat'); % Load time series data
y = y(:); % Ensure y is a column vector
N = length(y); % Number of samples

% Initialize dynamic perceptron parameters
mu = 1e-5; % Learning rate
order = 4; % AR(4) prediction model
w = zeros(order + 1, 1); % Initialize weights (including bias)
y_pred = zeros(N, 1); % Predicted output
e = zeros(N, 1); % Error signal

% Choose scaling factor a
a = 53; % You may try a = 0.5, 1, 1.5, 2 for comparison

% Prediction using tanh with bias and scaling factor
for n = order+1:N
    x_n = [1; y(n-1:-1:n-order)]; % Augmented input features (including bias)
    y_pred(n) = a * tanh(w' * x_n); % Prediction (with bias and scaling factor)
    e(n) = y(n) - y_pred(n); % Error calculation
    w = w + mu * e(n) * x_n; % LMS weight update (including bias)
end

% Compute Mean Squared Error (MSE) and Prediction Gain (Rp)
sigma_yhat2 = var(y_pred); % Variance of predicted signal y (including mean)
sigma_e2 = mean(e.^2); % Mean squared prediction error
Rp = 10 * log10(sigma_yhat2 / sigma_e2); % Prediction gain (dB)

% Plot results
figure;
plot(y, 'b', 'DisplayName', 'Original y[n] (Non-zero mean)');
hold on;
plot(y_pred, 'r--', 'DisplayName', ['Predicted y[n] with Bias & Scaling (a = ', num2str(a), ')']);
legend;
xlabel('Sample Index');
ylabel('Amplitude');
title(['Nonlinear Prediction with Bias & Scaling Activation: MSE = ', num2str(sigma_e2), ', Rp = ', num2str(Rp), ' dB']);
grid on;
hold off;
