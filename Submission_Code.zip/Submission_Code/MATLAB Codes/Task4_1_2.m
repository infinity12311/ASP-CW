clear; clc; close all;
% Load data
load('time-series.mat'); % Assume y is imported from the .mat file
y = y(:); % Ensure y is a column vector
N = length(y); % Number of samples

% Remove mean
y_mean = mean(y);
y_zero_mean = y - y_mean;

% Initialize dynamic perceptron parameters
mu = 1e-5; % Learning rate
order = 4; % Choose AR(4) model
w = zeros(order, 1); % Weight initialization
y_pred = zeros(N, 1); % Predicted output
e = zeros(N, 1); % Error signal

% Dynamical perceptron prediction (with tanh activation function)
for n = order+1:N
    x_n = y_zero_mean(n-1:-1:n-order); % Input features (y[n-1] to y[n-4])
    y_pred(n) = tanh(w' * x_n); % Prediction (with nonlinear activation)
    e(n) = y_zero_mean(n) - y_pred(n); % Error calculation
    w = w + mu * e(n) * x_n; % Weight update
end

% Compute Mean Squared Error (MSE) and Prediction Gain (Rp)
sigma_yhat2 = var(y_pred); % Variance of predicted signal y
sigma_e2 = var(e); % Variance of prediction error
Rp = 10 * log10(sigma_yhat2 / sigma_e2); % Prediction gain (dB)

% Plot results
figure;
plot(y_zero_mean, 'b', 'DisplayName', 'Zero-mean y[n]');
hold on;
plot(y_pred, 'r--', 'DisplayName', 'Predicted y[n] with tanh');
legend;
xlabel('Sample Index');
ylabel('Amplitude');
title(['Dynamical Perceptron Prediction: MSE = ', num2str(sigma_e2), ', Rp = ', num2str(Rp), ' dB']);
grid on;
hold off;
