clear; clc; close all;
% Load data
load('time-series.mat'); % Load time series data
y = y(:); % Ensure y is a column vector
N = length(y); % Number of samples

% Initialize parameters
mu = 1e-5; % Learning rate
order = 4; % AR(4) prediction model
epochs = 100; % Number of pretraining iterations
num_pretrain = 20; % Number of samples for pretraining
w = zeros(order + 1, 1); % Initialize weights (including bias)
a = 83; % Activation function scaling factor

% Pretraining phase: train weights using the first 20 samples
for epoch = 1:epochs
    for n = order+1:num_pretrain
        x_n = [1; y(n-1:-1:n-order)]; % Input data (including bias)
        y_pred_n = a * tanh(w' * x_n); % Compute nonlinear prediction
        e_n = y(n) - y_pred_n; % Compute error
        w = w + mu * e_n * x_n; % LMS weight update
    end
end
w_init = w; % Save weights after pretraining

% Predict the entire time series
y_pred = zeros(N, 1);
e = zeros(N, 1);
for n = order+1:N
    x_n = [1; y(n-1:-1:n-order)];
    y_pred(n) = a * tanh(w_init' * x_n); % Predict using pretrained w
    e(n) = y(n) - y_pred(n);
end

% Compute Mean Squared Error (MSE) and Prediction Gain (Rp)
sigma_yhat2 = var(y_pred); % Variance of predicted signal
sigma_e2 = mean(e.^2); % Mean squared prediction error
Rp = 10 * log10(sigma_yhat2 / sigma_e2); % Prediction gain (dB)

% Plot results
figure;
plot(y, 'b', 'DisplayName', 'Original y[n] (Non-zero mean)');
hold on;
plot(y_pred, 'r--', 'DisplayName', 'Predicted y[n] with Pretrained Weights');
legend;
xlabel('Sample Index');
ylabel('Amplitude');
title(['Pretrained Dynamical Perceptron Prediction: MSE = ', num2str(sigma_e2), ', Rp = ', num2str(Rp), ' dB']);
grid on;
hold off;
