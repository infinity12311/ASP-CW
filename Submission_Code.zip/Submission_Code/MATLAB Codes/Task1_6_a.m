clc; clear; close all;
addpath('./Function/');

%% **Step 1: Load Data**
load('PCAPCR.mat');  % Ensure that the file PCAPCR.mat is in the current directory

%% **Step 2: Compute Singular Values**
% Perform SVD on X
[U, S, V] = svd(X);
sigma_X = diag(S); % Extract singular values

% Perform SVD on X_noise
[U_noise, S_noise, V_noise] = svd(Xnoise);
sigma_X_noise = diag(S_noise); % Extract singular values

%% **Step 3: Plot Singular Values of X and X_noise**
figure;
subplot(2,1,1);
stem(sigma_X, 'b', 'filled');
hold on;
stem(sigma_X_noise, 'r', 'filled');
xlabel('Singular Value Index');
ylabel('Singular Value Magnitude');
title('Singular Values of X (blue) and X_{noise} (red)');
legend('X', 'X_{noise}');
grid on;

%% **Step 4: Compute Square Error (SE)**
SE = (sigma_X - sigma_X_noise).^2; % Compute square error

subplot(2,1,2);
stem(SE, 'k', 'filled');
xlabel('Singular Value Index');
ylabel('Square Error');
title('Square Error between Singular Values of X and X_{noise}');
grid on;


