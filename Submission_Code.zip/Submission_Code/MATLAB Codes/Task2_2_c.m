%% ========== 1. Parameter Settings ==========
clear; clc; close all;

N = 2000;                  % Data length
sigma2_v = 0.5;            % Noise variance
w_true = 0.9;              % True coefficient of MA(1) system
M = 1;                     % First-order filter
num_trials = 100;          % Number of Monte Carlo trials
mu_init = 0.1;             % Initial step-size
rho = 0.0002;              % Learning rate for step-size adaptation

% Initial regularization factor epsilon(1) for GNGD
eps_init = 0.1;            % Initial regularization term for GNGD

%% ========== 2. Define Storage Structures ==========
w_Ben_Avg  = zeros(M, N+1);  % Benveniste average
w_GNGD_Avg = zeros(M, N+1);  % GNGD average

%% ========== 3. Define Multiplication and Addition Counters (rough estimate) ==========
mulCount_Ben = 0; addCount_Ben = 0;
mulCount_GNGD = 0; addCount_GNGD = 0;

%% ========== 4. Monte Carlo Simulation ==========
for trial = 1:num_trials
    % ------ (a) Generate MA(1) process: x(n) = 0.9 * v(n-1) + v(n) ------
    v = sqrt(sigma2_v) * randn(N,1);
    x = zeros(N,1);
    for n = 2:N
        x(n) = w_true * v(n-1) + v(n);
    end
    
    % ===========================================================
    % ========== 4.1 Benveniste Algorithm (same as your version) ==========
    % ===========================================================
    w_Ben = zeros(M, N+1);       % Weights
    mu_Ben = zeros(1, N+1);      % Step-size
    e_Ben  = zeros(1, N+1);      % Error
    phi_Ben = zeros(M, N+1);     % Auxiliary variable phi
    
    mu_Ben(M+2) = mu_init;       % Initial step-size
    
    for nn = (M+2):N
        % Input u_n
        u_n = v(nn-1);    % For M=1, only use v(n-1)
        d_n = x(nn);      % Desired output
        w_n = w_Ben(:, nn);
        mu_n = mu_Ben(nn);
        
        % Error e(n)
        e_n = d_n - w_n' * u_n;
        e_Ben(nn) = e_n;
        
        % Weight update: w(n+1) = w(n) + mu(n)*e(n)*u(n)
        w_Ben(:, nn+1) = w_n + mu_n * e_n * u_n;
        
        % Benveniste: update phi(n)
        u_nm1 = v(nn-2);
        phi_nm1 = phi_Ben(:, nn-1);
        e_nm1 = e_Ben(nn-1);
        
        % phi(n) = [I - mu(n-1)*u(n-1)*u(n-1)^T]*phi(n-1) + e(n-1)*u(n-1)
        mu_nm1 = mu_Ben(nn-1);
        phi_n = (1 - mu_nm1*(u_nm1*u_nm1)) * phi_nm1 + e_nm1 * u_nm1;
        phi_Ben(:, nn) = phi_n;
        
        % Step-size update: mu(n+1) = mu(n) + rho * e(n)*(u(n)^T phi(n))
        mu_Ben(nn+1) = mu_n + rho * e_n * (u_n'*phi_n);
        
        % ========== Multiplication / Addition Count (rough) ==========
        % (1) Compute e(n): w_n'*u_n -> 1 mul + 1 add
        mulCount_Ben = mulCount_Ben + 1;
        addCount_Ben = addCount_Ben + 1;
        % (2) w(n+1)=... -> mu_n*e_n*u_n -> 2 mul + 1 add
        mulCount_Ben = mulCount_Ben + 2;
        addCount_Ben = addCount_Ben + 1;
        % (3) phi(n)=... includes some multiplications and additions (approximate)
        mulCount_Ben = mulCount_Ben + 2;
        addCount_Ben = addCount_Ben + 2;
        % (4) mu(n+1)=... -> e_n*(u_n'*phi_n) -> 2 mul + 1 add
        mulCount_Ben = mulCount_Ben + 2;
        addCount_Ben = addCount_Ben + 1;
    end
    
    % =======================================
    % ========== 4.2 GNGD Algorithm =========
    % =======================================
    w_GNGD = zeros(M, N+1);
    e_GNGD = zeros(1, N+1);
    epsArr = zeros(1, N+1);   % Regularization factor epsilon(n)
    epsArr(M+2) = eps_init;   % Initial regularization factor
    
    for nn = (M+2):N
        u_n = v(nn-1);
        d_n = x(nn);
        w_n = w_GNGD(:, nn);
%         eps_n = epsArr(nn);
        eps_n =1/mu_init;
%         beta_n= 0.01;
        beta_n= 1;
        
        % ---- Output & Error Calculation ----
        y_hat = w_n' * u_n;
        e_n = d_n - y_hat;
        e_GNGD(nn) = e_n;
        
        % ---- Weight Update: w(n+1) = w(n) + (beta(n)/(eps(n)+u_n^2))* e(n)*u(n) ----
        denom = (eps_n + u_n^2);
        w_GNGD(:, nn+1) = w_n + (beta_n / denom) * e_n * u_n;
        
        % ---- eps(n+1) Update (see Eq. (31)) ----
        e_nm1 = e_GNGD(nn-1);
        u_nm1 = v(nn-2);
        eps_nm1 = epsArr(nn-1);
        denom_nm1 = (eps_nm1 + u_nm1^2)^2;  % Denominator
        
        epsArr(nn+1) = eps_n - rho * mu_init * e_n*e_nm1*(u_n*u_nm1) / denom_nm1;
        
        % ========== Multiplication / Addition Count (rough) ==========
        % (1) y_hat = w_n'*u_n -> 1 mul + 1 add
        mulCount_GNGD = mulCount_GNGD + 1;
        addCount_GNGD = addCount_GNGD + 1;
        % (2) w(n+1)=... -> (beta_n/denom)* e_n*u_n -> ~3 mul + 1 add
        mulCount_GNGD = mulCount_GNGD + 3;
        addCount_GNGD = addCount_GNGD + 1;
        % (3) eps(n+1)=... involves several multiplications/divisions
        mulCount_GNGD = mulCount_GNGD + 4; % e_n*e_nm1*(u_n*u_nm1)*beta_n
        addCount_GNGD = addCount_GNGD + 1; % eps_n - ...
        % denom_nm1 -> (eps_nm1+u_nm1^2)^2 -> 2 mul + 1 add
        mulCount_GNGD = mulCount_GNGD + 2;
        addCount_GNGD = addCount_GNGD + 1;
    end
    
    % ------ Accumulate trial results ------
    w_Ben_Avg  = w_Ben_Avg  + w_Ben;
    w_GNGD_Avg = w_GNGD_Avg + w_GNGD;
end

%% ========== 5. Average over K Trials ==========
w_Ben_Avg  = w_Ben_Avg  / num_trials;
w_GNGD_Avg = w_GNGD_Avg / num_trials;

%% ========== 6. Plot: Benveniste vs GNGD ==========
figure; hold on; grid on;
plot(w_true - w_Ben_Avg(1,:), 'b', 'LineWidth',1.5, 'DisplayName','Benveniste (\mu(0)=0.01)');
plot(w_true - w_GNGD_Avg(1,:), 'r', 'LineWidth',1.5, 'DisplayName','GNGD (\mu=0.01)');
xlabel('Iteration n'); 
ylabel('Weight Error = 0.9 - w(n)');
title('Comparison: Benveniste vs GNGD on MA(1) System (\mu=0.01)');
legend('Location','best');
xlim([0,2100]);

%% ========== 7. Output Multiplication / Addition Count Comparison (rough) ==========
disp('==================== Complexity Comparison ====================');
disp(['Benveniste -> Multiplications: ', num2str(mulCount_Ben), ...
      ', Additions: ', num2str(addCount_Ben)]);
disp(['GNGD       -> Multiplications: ', num2str(mulCount_GNGD), ...
      ', Additions: ', num2str(addCount_GNGD)]);
disp('==============================================================');
