clc; clear; close all;
addpath('./Function/');

%% **Step 1: Set Signal Parameters**
N = 32; % Signal length
fs = 200; % Sampling frequency (Hz)
t = (0:N-1)/fs; % Time axis
nfft = 2048; % Number of FFT points
f = fs*(0:(nfft/2))/nfft; % Frequency axis
num_realizations = 100; % 100 realizations of the random process

% Preallocate variables
psd_all = zeros(num_realizations, nfft);
acf_biased_all = zeros(num_realizations, 2*N-1);

%% **Step 2: Generate Multiple Random Processes**
for i = 1:num_realizations
    % Generate noisy sinusoidal signal: two sine waves + WGN
    x = 0.6*sin(2*pi*35*t) + sin(2*pi*50*t) + 0.5*randn(1, length(t));
    
    % Compute Biased ACF
    [acf_biased, k_biased] = fACF(x, 'biased');
    acf_biased_all(i, :) = acf_biased;

    % Compute Correlogram PSD
    [PSD_biased] = fCorrelogram(acf_biased, nfft, k_biased, '');
    psd_all(i, :) = PSD_biased;
end

%% **Step 3: Plot PSD Overlays for 100 Realizations**
figure;
subplot(2,1,1)
hold on;
for i = 1:num_realizations
    plot(f, psd_all(i,1:nfft/2+1), 'c'); % Overlay 100 PSD realizations
end
plot(f, mean(psd_all(:,1:nfft/2+1),1), 'b', 'LineWidth', 2); % Plot mean PSD
grid on;
xlabel('Frequency (Hz)');
ylabel('Power Spectral Density / Hz');
title('PSD estimates (100 realizations and mean)');

%% **Step 4: Compute Mean and Standard Deviation of PSD**
psd_mean = mean(psd_all, 1);
psd_std = std(psd_all, 0, 1);

%% **Step 5: Plot Mean and Standard Deviation**
subplot(2,1,2)
plot(f, psd_std(1:nfft/2+1), 'r-', 'LineWidth', 1.5);
grid on;
xlabel('Frequency (Hz)');
ylabel('Magnitude (dB)');
title('Standard Deviation');

%% **Plotting in dB**

% Average
psd_all_dB = 10*log10(psd_all);
figure;
subplot(2,1,1);
for i = 1:num_realizations
    psd_dB = psd_all_dB(i,:);
    plot(f, psd_dB(1:nfft/2+1),'-c');
    hold on;
end

PSD_dB_mean = mean(psd_all_dB(:,1:nfft/2+1),1);
plot(f, PSD_dB_mean,'-b','LineWidth', 2);
grid on;
xlabel('Frequency (Hz)');
ylabel('Power Spectral Density (dB/Hz)');
title('PSD estimates (100 realizations and mean)-dB');

% Standard deviation
psd_dB_std = std(psd_all_dB, 0, 1);
subplot(2,1,2);
plot(f, psd_dB_std(1:nfft/2+1),'-r','LineWidth', 2);
grid on;
xlabel('Frequency (Hz)');
ylabel('Magnitude (dB/Hz)');
title('Standard Deviation-dB');
