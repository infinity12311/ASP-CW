clc; clear; close all;

%% Parameter settings
N = 512;  % Signal length
fs = 1000; % Sampling rate (Hz)
t = (0:N-1)/fs; % Time axis
f_axis = linspace(-fs/2, fs/2, N); % Frequency axis
lags = -N+1:N-1; % Lag index

%% **Rapidly Decaying Signal (Impulse Signal x1(t) = δ(t))**
x1 = zeros(1, N); 
x1(N/2) = 1; % Generate a unit impulse at the center point

% Compute the autocorrelation function
r_x1 = xcorr(x1, 'unbiased');

% Compute PSD (Definition 1: Based on the autocorrelation function)
PSD_x1_def1 = abs(fftshift(fft(r_x1, N))); 

% Compute PSD (Definition 2: Based on time averaging)
X1_f = fftshift(fft(x1, N)); % Fourier transform of the signal
PSD_x1_def2 = abs(X1_f).^2 / N; 

% **Plot time series, ACF, and PSD for the rapidly decaying signal**
figure;
subplot(3,1,1);
stem(t, x1, 'k.', 'MarkerSize', 4);
xlabel('Time (s)');
ylabel('Amplitude');
title('Time Series: Impulse Signal');
grid on;

subplot(3,1,2);
plot(lags/fs, r_x1, 'b', 'LineWidth', 1.5);
xlabel('Lag (s)');
ylabel('ACF');
title('Autocorrelation Function (ACF): Impulse Signal');
grid on;

subplot(3,1,3);
plot(f_axis, 10*log10(PSD_x1_def1), 'r', 'LineWidth', 1.5);
hold on;
plot(f_axis, 10*log10(PSD_x1_def2), 'b--', 'LineWidth', 1.5);
xlabel('Frequency (Hz)');
ylabel('PSD (dB)');
title('PSD Comparison: Impulse Signal');
legend('PSD from ACF (Definition 1)', 'PSD from Fourier Transform (Definition 2)');
grid on;


%% **Slowly Decaying Signal (AR(1) Process)**
phi = 0.99; % AR(1) coefficient, close to 1 to make ACF decay slowly
w = randn(1, N); % White noise
x2 = filter(1, [1, -phi], w); % Generate AR(1) process

% Compute the autocorrelation function
r_x2 = xcorr(x2, 'unbiased');

% Compute PSD (Definition 1: Based on the autocorrelation function)
PSD_x2_def1 = abs(fftshift(fft(r_x2, N))); 

% Compute PSD (Definition 2: Based on time averaging)
X2_f = fftshift(fft(x2, N)); % Fourier transform of the signal
PSD_x2_def2 = abs(X2_f).^2 / N; 

% **Plot time series, ACF, and PSD for the slowly decaying signal**
figure;
subplot(3,1,1);
plot(t, x2, 'k', 'LineWidth', 1.2);
xlabel('Time (s)');
ylabel('Amplitude');
title('Time Series: AR(1) Process');
grid on;

subplot(3,1,2);
plot(lags/fs, r_x2, 'b', 'LineWidth', 1.5);
xlabel('Lag (s)');
ylabel('ACF');
title('Autocorrelation Function (ACF): AR(1) Process');
grid on;

subplot(3,1,3);
plot(f_axis, 10*log10(PSD_x2_def1), 'r', 'LineWidth', 1.5);
hold on;
plot(f_axis, 10*log10(PSD_x2_def2), 'b--', 'LineWidth', 1.5);
xlabel('Frequency (Hz)');
ylabel('PSD (dB)');
title('PSD Comparison: AR(1) Process');
legend('PSD from ACF (Definition 1)', 'PSD from Fourier Transform (Definition 2)');
grid on;
