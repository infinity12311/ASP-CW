clc; clear; close all;

% 参数设置
mu = 0.01;  % 学习率
b1 = 1.5 + 1j;
b2 = 2.5 - 0.5j;
num_trials = 100; % 进行100次独立实验以获得平滑学习曲线
N = 1000; % 样本数
M = 1; % 滤波器阶数

% 预分配误差存储变量
errors_CLMS = zeros(1, N);
errors_ACLMS = zeros(1, N);

% 进行多次实验以计算平均学习曲线
for i = 1:num_trials
    % 生成输入信号（圆形高斯白噪声）
    x = (randn(N+1, 1) + 1j * randn(N+1, 1)) / sqrt(2);

    % 生成WLMA(1)过程
    y = zeros(N+1, 1);
    for n = 2:N+1
        y(n) = x(n) + b1 * x(n-1) + b2 * conj(x(n-1));
    end

    % CLMS 计算
    h = zeros(M, 1); % CLMS 滤波器系数初始化
    error_CLMS = zeros(1, N);
    for n = M+1:N+1
        x_segment = x(n-1:-1:n-M); % 输入数据段
        y_hat = h' * x_segment; % 预测输出
        error_CLMS(n-M) = y(n) - y_hat; % 误差计算
        h = h + mu * conj(error_CLMS(n-M)) * x_segment; % 更新权重
    end

    % ACLMS 计算
    h_a = zeros(M, 1); % ACLMS h 滤波器系数
    g_a = zeros(M, 1); % ACLMS g 滤波器系数
    error_ACLMS = zeros(1, N);
    for n = M+1:N+1
        x_segment = x(n-1:-1:n-M); % 输入数据段
        y_hat_A = h_a' * x_segment + g_a' * conj(x_segment); % 预测输出
        error_ACLMS(n-M) = y(n) - y_hat_A; % 误差计算
        h_a = h_a + mu * conj(error_ACLMS(n-M)) * x_segment; % 更新 h
        g_a = g_a + mu * conj(error_ACLMS(n-M)) * conj(x_segment); % 更新 g
    end

    % 记录误差平方
    errors_CLMS = errors_CLMS + abs(error_CLMS).^2;
    errors_ACLMS = errors_ACLMS + abs(error_ACLMS).^2;
end

% 计算学习曲线（对数尺度）
errors_CLMS_avg = pow2db(errors_CLMS / num_trials);
errors_ACLMS_avg = pow2db(errors_ACLMS / num_trials);

% 绘制学习曲线
figure;
plot(errors_ACLMS_avg, '-b', 'LineWidth', 1.5); hold on;
plot(errors_CLMS_avg, '-r', 'LineWidth', 1.5);
grid on;
xlabel('Iteration', 'FontSize', 12);
ylabel('10log|e(n)|^2 (dB)', 'FontSize', 12);
title('Learning Curve: CLMS vs ACLMS', 'FontSize', 14);
legend('ACLMS', 'CLMS', 'FontSize', 12);
set(gcf, 'Position', [100, 100, 800, 600]);
