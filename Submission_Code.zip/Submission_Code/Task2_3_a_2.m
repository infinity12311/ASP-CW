clc; clear; close all;

% 参数设置
N = 1000; % 信号长度
mu = 0.01; % 学习率
num_realizations = 100; % 实验次数
delta_values = 3:25; % 选择不同的延迟 Δ
M_values = [5, 10, 15, 20]; % 不同的预测器阶数 M
num_deltas = length(delta_values);
num_M = length(M_values);

% 预分配存储 MSPE 结果
MSPE_results = zeros(num_deltas, num_M);

% 遍历不同的 M 值
for m_idx = 1:num_M
    M = M_values(m_idx);
    
    % 遍历不同的 delta 进行实验
    for d_idx = 1:num_deltas
        delta = delta_values(d_idx);
        MSPE_all = zeros(N, num_realizations); % 存储误差信号
        
        for realization = 1:num_realizations
            % 生成信号
            n = (0:N-1)';
            x = sin(0.01 * pi * n); % 真实信号
            v = randn(N,1); % 白噪声
            eta = v + 0.5 * [zeros(2,1); v(1:end-2)]; % 颜色噪声
            s = x + eta; % 噪声污染信号
            
            % 自适应滤波初始化
            w = zeros(M,1); % 线性预测器权重
            x_hat = zeros(N,1); % 估计的干净信号
            e = zeros(N,1); % 误差信号

            % LMS 迭代
            for n = M+delta:N
                u = s(n-delta:-1:n-delta-M+1);
                x_hat(n) = w' * u;
                e(n) = s(n) - x_hat(n);
                w = w + mu * e(n) * u;
            end
            
            % 存储误差信号
            MSPE_all(:, realization) = x-x_hat;
        end

        % 计算均方预测误差 (MSPE)
        MSPE_results(d_idx, m_idx) = mean(mean(MSPE_all.^2));
    end
end

% 转换 MSPE 为 dB
MSPE_dB = 10 * log10(MSPE_results);

% 画 MSPE vs Delay 图
figure;
hold on;
colors = lines(num_M); % 生成颜色
markers = {'o', 's', '^', 'd'}; % 标记样式

for m_idx = 1:num_M
    plot(delta_values, MSPE_dB(:, m_idx), ...
        'Color', colors(m_idx, :), 'LineWidth', 1.5, ...
        'Marker', markers{m_idx}, 'MarkerSize', 6, ...
        'DisplayName', ['M = ', num2str(M_values(m_idx))]);
end

% 设置图例和标签
legend('show', 'Location', 'northwest');
xlabel('Delay \Delta');
ylabel('MSPE (dB)');
title('MSPE of specific filter orders against delays');
grid on;
hold off;
