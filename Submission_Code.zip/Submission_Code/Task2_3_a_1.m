clc; clear; close all;

% Parameter settings
N = 1000; % Signal length
M = 5; % Predictor order
mu = 0.01; % Learning rate
num_realizations = 100; % Number of experiments
delta_values = [0, 1, 2, 3, 4, 5]; % Different delay values Δ
num_deltas = length(delta_values); % Number of delay values

% Generate the clean signal
n = (0:N-1)';
x = sin(0.01 * pi * n); % True signal

% Prepare figure
figure;
tiledlayout(num_deltas, 1); % Use tiledlayout to arrange subplots for each delta

% Iterate over different delta values
for idx = 1:num_deltas
    delta = delta_values(idx);
    x_hat_all = zeros(N, num_realizations); % Store all estimated signals

    for realization = 1:num_realizations
        % Generate noise signal
        v = randn(N,1); % White noise
        eta = v + 0.5 * [zeros(2,1); v(1:end-2)]; % Colored noise
        s = x + eta; % Noisy signal

        % Initialize adaptive filter
        w = zeros(M,1); % Linear predictor weights
        x_hat = zeros(N,1); % Estimated clean signal

        % LMS iteration
        for n = M+delta:N
            u = s(n-delta:-1:n-delta-M+1);
            x_hat(n) = w' * u;
            e = s(n) - x_hat(n);
            w = w + mu * e * u;
        end

        % Store the results of the current experiment
        x_hat_all(:, realization) = x_hat;
    end

    % Compute the average recovered signal
    x_hat_mean = mean(x_hat_all, 2);

    % Plot the recovered signals for different delta values
    nexttile;
    plot(x, 'k--', 'LineWidth', 2, 'DisplayName', 'True signal x(n)'); % True signal
    hold on;
    plot(x_hat_mean, 'r', 'LineWidth', 1.5, 'DisplayName', ['Recovered signal \Delta=', num2str(delta)]);
    legend('show');
    xlabel('Sample index n');
    ylabel('Amplitude');
    title(['Delay \Delta = ', num2str(delta)]);
    grid on;
end

% Overall title
sgtitle('True Signal and Adaptive Filtering Recovery for Different Delays \Delta');


% clc; clear; close all;
% 
% % 参数设置
% N = 1000; % 信号长度
% M = 5; % 预测器阶数
% mu = 0.01; % 学习率
% num_realizations = 100; % 实验次数
% delta_values = [1, 2, 3, 4, 5, 6]; % 选择不同的延迟 Δ
% num_deltas = length(delta_values); % 延迟数量
% 
% % 生成纯信号
% n = (0:N-1)';
% x = sin(0.01 * pi * n); % 真实信号
% 
% % 画图准备
% figure;
% tiledlayout(num_deltas, 1); % 使用 tiledlayout 进行排列，每个delta单独一个subplot
% 
% % 遍历不同的 delta 进行实验
% for idx = 1:num_deltas
%     delta = delta_values(idx);
%     x_hat_all = zeros(N, num_realizations); % 存储所有实验的估计信号
% 
%     for realization = 1:num_realizations
%         % 生成噪声信号
%         v = randn(N,1); % 白噪声
%         eta = v + 0.5 * [zeros(2,1); v(1:end-2)]; % 颜色噪声
%         s = x + eta; % 噪声污染信号
% 
%         % 自适应滤波初始化
%         w = zeros(M,1); % 线性预测器权重
%         x_hat = zeros(N,1); % 估计的干净信号
% 
%         % LMS 迭代
%         for n = M+delta:N
%             u = s(n-delta:-1:n-delta-M+1);
%             x_hat(n) = w' * u;
%             e = s(n) - x_hat(n);
%             w = w + mu * e * u;
%         end
% 
%         % 存储当前实验的结果
%         x_hat_all(:, realization) = x_hat;
%     end
% 
%     % 计算平均恢复信号
%     x_hat_mean = mean(x_hat_all, 2);
% 
%     % 在 subplot 中绘制不同 delta 的恢复信号
%     nexttile;
%     plot(x, 'k--', 'LineWidth', 2, 'DisplayName', '真实信号 x(n)'); % 真实信号
%     hold on;
%     plot(x_hat_mean, 'r', 'LineWidth', 1.5, 'DisplayName', ['恢复信号 \Delta=', num2str(delta)]);
%     legend('show');
%     xlabel('样本索引 n');
%     ylabel('幅值');
%     title(['延迟 \Delta = ', num2str(delta)]);
%     grid on;
% end
% 
% % 总标题
% sgtitle('不同延迟 \Delta 下的真实信号与自适应滤波恢复信号');


