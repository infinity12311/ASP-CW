clear; clc; close all;
% 加载数据
load('time-series.mat'); % 读取时间序列数据
y = y(:); % 确保 y 是列向量
N = length(y); % 样本数

% 初始化参数
mu = 1e-5; % 学习率
order = 4; % AR(4) 预测模型
epochs = 100; % 预训练迭代次数
num_pretrain = 20; % 预训练样本数
w = zeros(order + 1, 1); % 初始化权重 (包含 bias)
a = 83; % 激活函数缩放因子

% 预训练阶段：使用前 20 个样本进行权重训练
for epoch = 1:epochs
    for n = order+1:num_pretrain
        x_n = [1; y(n-1:-1:n-order)]; % 输入数据 (包含 bias)
        y_pred_n = a * tanh(w' * x_n); % 计算非线性预测
        e_n = y(n) - y_pred_n; % 计算误差
        w = w + mu * e_n * x_n; % LMS 权重更新
    end
end
w_init = w; % 保存预训练后的权重

% 预测整个时间序列
y_pred = zeros(N, 1);
e = zeros(N, 1);
for n = order+1:N
    x_n = [1; y(n-1:-1:n-order)];
    y_pred(n) = a * tanh(w_init' * x_n); % 使用预训练的 w 进行预测
    e(n) = y(n) - y_pred(n);
end

% 计算均方误差 (MSE) 和预测增益 (Rp)
sigma_yhat2 = var(y_pred); % 预测信号的方差
sigma_e2 = mean(e.^2); % 预测误差的均方误差
Rp = 10 * log10(sigma_yhat2 / sigma_e2); % 计算预测增益 (dB)

% 绘制结果
figure;
plot(y, 'b', 'DisplayName', 'Original y[n] (Non-zero mean)');
hold on;
plot(y_pred, 'r--', 'DisplayName', 'Predicted y[n] with Pretrained Weights');
legend;
xlabel('Sample Index');
ylabel('Amplitude');
title(['Pretrained Dynamical Perceptron Prediction: MSE = ', num2str(sigma_e2), ', Rp = ', num2str(Rp), ' dB']);
grid on;
hold off;
