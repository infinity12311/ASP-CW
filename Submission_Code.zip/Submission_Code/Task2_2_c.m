%% ========== 1. 参数设置 ==========
clear; clc; close all;

N = 2000;                  % 数据长度
sigma2_v = 0.5;            % 噪声方差
w_true = 0.9;              % MA(1)系统实际系数
M = 1;                     % 一阶滤波器
num_trials = 100;           % 蒙特卡洛试验次数 (可自行调节)
mu_init = 0.1;            % 初始步长
rho = 0.0002;              % 步长调节的学习率

% GNGD 中的初始正则因子 epsilon(1)
eps_init = 0.1;           % GNGD初始正则项

%% ========== 2. 定义存储结构 ==========
w_Ben_Avg  = zeros(M, N+1);  % Benveniste 均值
w_GNGD_Avg = zeros(M, N+1);  % GNGD 均值

%% ========== 3. 定义乘法与加法计数器(粗略统计) ==========
mulCount_Ben = 0; addCount_Ben = 0;
mulCount_GNGD = 0; addCount_GNGD = 0;

%% ========== 4. 蒙特卡洛试验 ==========
for trial = 1:num_trials
    % ------ (a) 生成MA(1)过程： x(n) = 0.9 * v(n-1) + v(n) ------
    v = sqrt(sigma2_v) * randn(N,1);
    x = zeros(N,1);
    for n = 2:N
        x(n) = w_true * v(n-1) + v(n);
    end
    
    % ===========================================================
    % ========== 4.1 Benveniste算法 (与您提供的版本相同) ==========
    % ===========================================================
    w_Ben = zeros(M, N+1);       % 权值
    mu_Ben = zeros(1, N+1);      % 步长
    e_Ben  = zeros(1, N+1);      % 误差
    phi_Ben = zeros(M, N+1);     % phi 辅助变量
    
    mu_Ben(M+2) = mu_init;       % 初始步长
    
    for nn = (M+2):N
        % 输入u_n
        u_n = v(nn-1);    % 对于M=1, 只用v(n-1)
        d_n = x(nn);      % 期望输出
        w_n = w_Ben(:, nn);
        mu_n = mu_Ben(nn);
        
        % 误差 e(n)
        e_n = d_n - w_n' * u_n;
        e_Ben(nn) = e_n;
        
        % 权值更新: w(n+1) = w(n) + mu(n)*e(n)*u(n)
        w_Ben(:, nn+1) = w_n + mu_n * e_n * u_n;
        
        % Benveniste: phi(n) 更新
        u_nm1 = v(nn-2);
        phi_nm1 = phi_Ben(:, nn-1);
        e_nm1 = e_Ben(nn-1);
        
        % phi(n) = [I - mu(n-1)*u(n-1)*u(n-1)^T]*phi(n-1) + e(n-1)*u(n-1)
        mu_nm1 = mu_Ben(nn-1);
        phi_n = (1 - mu_nm1*(u_nm1*u_nm1)) * phi_nm1 + e_nm1 * u_nm1;
        phi_Ben(:, nn) = phi_n;
        
        % 步长更新: mu(n+1) = mu(n) + rho * e(n)*(u(n)^T phi(n))
        mu_Ben(nn+1) = mu_n + rho * e_n * (u_n'*phi_n);
        
        % ========== 乘法/加法计数 (粗略) ==========
        % (1) 计算 e(n): w_n'*u_n -> 1 mul + 1 add, e_n=...
        mulCount_Ben = mulCount_Ben + 1;
        addCount_Ben = addCount_Ben + 1;
        % (2) w(n+1)=... -> mu_n*e_n*u_n -> 2 mul + 1 add
        mulCount_Ben = mulCount_Ben + 2;
        addCount_Ben = addCount_Ben + 1;
        % (3) phi(n)=... 里也有若干乘法加法 (这里统一简化处理)
        mulCount_Ben = mulCount_Ben + 2;
        addCount_Ben = addCount_Ben + 2;
        % (4) mu(n+1)=... -> e_n*(u_n'*phi_n) -> 2 mul + 1 add
        mulCount_Ben = mulCount_Ben + 2;
        addCount_Ben = addCount_Ben + 1;
    end
    
    % =======================================
    % ========== 4.2 GNGD算法 ===============
    % =======================================
    w_GNGD = zeros(M, N+1);
    e_GNGD = zeros(1, N+1);
    epsArr = zeros(1, N+1);   % 正则因子 epsilon(n)
    epsArr(M+2) = eps_init;   % 初始正则因子
    
    for nn = (M+2):N
        u_n = v(nn-1);
        d_n = x(nn);
        w_n = w_GNGD(:, nn);
%         eps_n = epsArr(nn);
        eps_n =1/mu_init;
%         beta_n= 0.01;
        beta_n= 1;
        
        % ---- 计算输出 & 误差 ----
        y_hat = w_n' * u_n;
        e_n = d_n - y_hat;
        e_GNGD(nn) = e_n;
        
        % ---- 权值更新 w(n+1) = w(n) + (beta(n)/(eps(n)+u_n^2))* e(n)*u(n) ----
        denom = (eps_n + u_n^2);
        w_GNGD(:, nn+1) = w_n + (beta_n / denom) * e_n * u_n;
        
        % ---- eps(n+1) 更新 (参见公式(31)) ----
        e_nm1 = e_GNGD(nn-1);
        u_nm1 = v(nn-2);
        eps_nm1 = epsArr(nn-1);
        denom_nm1 = (eps_nm1 + u_nm1^2)^2;  % 分母
        
        epsArr(nn+1) = eps_n - rho * mu_init * e_n*e_nm1*(u_n*u_nm1) / denom_nm1;
        
        % ========== 乘法/加法计数 (粗略) ==========
        % (1) y_hat = w_n'*u_n -> 1 mul +1 add
        mulCount_GNGD = mulCount_GNGD + 1;
        addCount_GNGD = addCount_GNGD + 1;
        % (2) w(n+1)=... -> (beta_n/denom)* e_n*u_n -> ~3 mul +1 add
        mulCount_GNGD = mulCount_GNGD + 3;
        addCount_GNGD = addCount_GNGD + 1;
        % (3) eps(n+1)=... -> 包含若干乘除
        mulCount_GNGD = mulCount_GNGD + 4; % e_n*e_nm1*(u_n*u_nm1)*beta_n
        addCount_GNGD = addCount_GNGD + 1; % eps_n - ...
        % denom_nm1 -> (eps_nm1+u_nm1^2)^2 -> 2 mul +1 add
        mulCount_GNGD = mulCount_GNGD + 2;
        addCount_GNGD = addCount_GNGD + 1;
    end
    
    % ------ 将本次试验结果累加 ------
    w_Ben_Avg  = w_Ben_Avg  + w_Ben;
    w_GNGD_Avg = w_GNGD_Avg + w_GNGD;
end

%% ========== 5. K次试验结果取平均 ==========
w_Ben_Avg  = w_Ben_Avg  / num_trials;
w_GNGD_Avg = w_GNGD_Avg / num_trials;

%% ========== 6. 绘图：Benveniste vs GNGD ==========
figure; hold on; grid on;
plot(w_true - w_Ben_Avg(1,:), 'b', 'LineWidth',1.5, 'DisplayName','Benveniste (\mu(0)=0.01)');
plot(w_true - w_GNGD_Avg(1,:), 'r', 'LineWidth',1.5, 'DisplayName','GNGD (\mu=0.01)');
xlabel('Iteration n'); 
ylabel('Weight Error = 0.9 - w(n)');
title('Comparison: Benveniste vs GNGD on MA(1) System (\mu=0.01)');
legend('Location','best');
xlim([0,2100]);

%% ========== 7. 输出乘法/加法次数对比 (粗略) ==========
disp('==================== Complexity Comparison ====================');
disp(['Benveniste -> Multiplications: ', num2str(mulCount_Ben), ...
      ', Additions: ', num2str(addCount_Ben)]);
disp(['GNGD       -> Multiplications: ', num2str(mulCount_GNGD), ...
      ', Additions: ', num2str(addCount_GNGD)]);
disp('==============================================================');
