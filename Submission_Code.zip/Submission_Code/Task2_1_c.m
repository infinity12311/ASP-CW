% %% ========== 0. 参数与初始化 ==========
% clear; clc; close all;
% 
% % AR(2) 系数 (与题目一致)
% a1 = 0.1; 
% a2 = 0.8; 
% sigma2_eta = 0.25;  % 噪声方差
% 
% % LMS 相关
% mu = 0.01;          % 步长(可自行改为0.05再跑一次)
% M = 2;              % 预测器阶数: 用 x(n-1), x(n-2)
% N = 1000;           % 每条试验的数据长度
% numReal = 100;      % 重复试验次数
% steadyStateStart = 600;  % 从第600次迭代开始视为稳态
% 
% % 理论自相关矩阵 R (可由Yule-Walker方程或课件给出)
% % 这里直接用已知解: r(0)=0.9259, r(1)=0.4629
% r0 = 0.9259; 
% r1 = 0.4629;
% R_theory = [r0 r1; r1 r0];
% traceR = trace(R_theory);
% 
% % 预分配误差存储: e2_all(realization, n)
% e2_all = zeros(numReal, N);
% 
% %% ========== 1. 多次试验, 记录瞬时误差平方 ==========
% for realization = 1:numReal
%     % --- (a) 生成 AR(2) 数据 ---
%     w = sqrt(sigma2_eta)*randn(N,1);  % 白噪声
%     x = zeros(N,1);
%     x(1)=0; x(2)=0;                   % 初值
%     for n=3:N
%         x(n) = a1*x(n-1) + a2*x(n-2) + w(n);
%     end
% 
%     % --- (b) 初始化 LMS ---
%     wLMS = zeros(M,1);  % [w1; w2]
%     e_save = zeros(N,1);
% 
%     % --- (c) 逐点在线更新 ---
%     for n=3:N
%         u = [x(n-1); x(n-2)];   % 输入向量
%         x_hat = wLMS' * u;     % 预测输出
%         e_n = x(n) - x_hat;    % 误差
%         e_save(n) = e_n;
% 
%         % LMS 权值更新
%         wLMS = wLMS + mu * e_n * u;
%     end
% 
%     % --- (d) 存下瞬时误差平方 ---
%     e2_all(realization,:) = e_save.^2;
% end
% 
% %% ========== 2. 计算学习曲线(ensemble平均) 并估计失调量 ==========
% % (a) 对 100 条曲线在第 n 点做平均 -> 得到 e2_ens(n)
% e2_ens = mean(e2_all, 1);  % (1 x N)
% 
% % (b) 选取稳态区间(例如 n=600:1000) 做时间平均
% e2_ss = mean(e2_ens(steadyStateStart:end));  % 稳态均值
% 
% % (c) 计算实验得到的 MSE, EMSE, 以及失调量 M
% MSE_ss = e2_ss;                         % 稳态区的均方误差
% EMSE = MSE_ss - sigma2_eta;            % 过量均方误差
% M_est = EMSE / sigma2_eta;             % 实验估计的失调量
% 
% % (d) 理论值
% M_theory = (mu/2)*traceR;  % 对小步长近似成立
% 
% % 输出结果
% fprintf('\n=== 结果汇总(步长 mu = %.3f) ===\n', mu);
% fprintf('稳态区 MSE (实验)    = %.4f\n', MSE_ss);
% fprintf('实验估计的 misadjust = %.4f\n', M_est);
% fprintf('理论近似 misadjust   = %.4f\n', M_theory);

%% ========== 0. 参数与初始化 ==========
clear; clc; close all;

% AR(2) 系数 (与题目一致)
a1 = 0.1; 
a2 = 0.8; 
sigma2_eta = 0.25;  % 噪声方差

% 要估计的滤波器阶数 (预测器: x(n-1), x(n-2))
M = 2;

% 两个步长 (可以自行修改或增加)
mu_list = [0.05, 0.01];

% 其它设置
N = 1000;               % 每条试验的数据长度
numReal = 100;          % 重复试验次数
steadyStateStart = 600; % 稳态区起始点(如题意，可自行调整)

% 理论自相关矩阵 R (由 Yule-Walker 或课件可得)
% 这里直接用已知数值: r(0)=0.9259, r(1)=0.4629
r0 = 0.9259; 
r1 = 0.4629;
R_theory = [r0 r1; r1 r0];
traceR = trace(R_theory);

%% ========== 用于存储误差的数组 ==========
% e2_all(mu_idx, realization, n)
e2_all = zeros(length(mu_list), numReal, N);

%% ========== 1. 多次试验，记录瞬时误差平方 ==========
for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);
    
    for realization = 1:numReal
        % --- (a) 生成 AR(2) 数据 ---
        w_noise = sqrt(sigma2_eta)*randn(N,1);  
        x = zeros(N,1);
        x(1)=0; x(2)=0;  % 初值
        for n=3:N
            x(n) = a1*x(n-1) + a2*x(n-2) + w_noise(n);
        end

        % --- (b) LMS 初始化 ---
        wLMS = zeros(M,1);  % 权值向量 [w1; w2]
        e_save = zeros(N,1);

        % --- (c) 逐点在线更新，记录误差 ---
        for n=3:N
            u = [x(n-1); x(n-2)];
            x_hat = wLMS' * u;
            e_n = x(n) - x_hat;
            e_save(n) = e_n;

            % LMS 更新
            wLMS = wLMS + mu * e_n * u;
        end

        % --- (d) 存下瞬时误差平方 ---
        e2_all(mu_idx, realization, :) = e_save.^2;
    end
end

%% ========== 2. 对每个步长, 计算学习曲线(ensemble平均) 并估计失调量 ==========
% 为了演示, 我们输出每个步长下的:
% 1) 稳态区 MSE
% 2) EMSE = MSE - sigma2_eta
% 3) misadjustment M = EMSE / sigma2_eta
% 4) 理论近似 misadjustment = (mu/2)*trace(R)

for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);

    % --- (a) 对 numReal 条曲线在每个 n 做平均 -> 得到 e2_ens(n)
    e2_ens = mean( squeeze(e2_all(mu_idx,:,:)), 1 );  % (1 x N)

    % --- (b) 选取稳态区间(例如 n=600~1000) 做时间平均
    e2_ss = mean(e2_ens(steadyStateStart:end));  % 稳态区的均方误差

    % --- (c) 计算实验得到的 MSE, EMSE, misadjustment
    MSE_ss = e2_ss;                       % 稳态区 MSE
    EMSE = MSE_ss - sigma2_eta;          % 过量均方误差
    M_est = EMSE / sigma2_eta;           % 实验估计的失调量

    % --- (d) 理论失调量近似(对小步长)
    M_theory = (mu/2)*traceR;

    % --- (e) 输出结果 ---
    fprintf('\n=== 对步长 mu = %.3f 的结果 ===\n', mu);
    fprintf('稳态区 MSE (实验)     = %.4f\n', MSE_ss);
    fprintf('过量MSE(EMSE)         = %.4f\n', EMSE);
    fprintf('实验估计的失调量 M    = %.4f\n', M_est);
    fprintf('理论近似失调量 M_th   = %.4f\n', M_theory);
    fprintf('差值   = %.4f\n', abs(M_theory-M_est));
end

