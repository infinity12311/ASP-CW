clc; clear; close all;
addpath('./Function/');  % Add Function folder path

%% **Step 1: Load Data**
load('PCAPCR.mat');  % Ensure PCAPCR.mat is in the current directory

%% **Step 2: Compute OLS and PCR Regression Coefficients**
% Compute OLS regression coefficients
B_OLS = (Xnoise' * Xnoise) \ (Xnoise' * Y); 

% Compute SVD of Xnoise
[U_noise, S_noise, V_noise] = svd(Xnoise);

% Select the first r most important principal components (using 80% of the energy)
sigma_X_noise = diag(S_noise);
energy_ratio = cumsum(sigma_X_noise) / sum(sigma_X_noise);
r = find(energy_ratio > 0.8, 1); 

% Retain only the first r principal components and compute PCR regression coefficients
V_r = V_noise(:, 1:r);
S_r = S_noise(1:r, 1:r);
U_r = U_noise(:, 1:r);
B_PCR = V_r * (S_r \ (U_r' * Y));

%% **Step 3: Perform 10000 Regression Predictions and Compute Mean Squared Error (MSE)**
loops = 10000;
MSE_OLS_total = 0;
MSE_PCR_total = 0;

for i = 1:loops
    % OLS Prediction
    [Yhat_OLS, Y_true] = regval(B_OLS);
    MSE_OLS_total = MSE_OLS_total + mean(mean((Y_true - Yhat_OLS).^2));

    % PCR Prediction
    [Yhat_PCR, Y_true] = regval(B_PCR);
    MSE_PCR_total = MSE_PCR_total + mean(mean((Y_true - Yhat_PCR).^2));
end

% Compute the average MSE over 10000 tests
MSE_OLS_avg = MSE_OLS_total / loops;
MSE_PCR_avg = MSE_PCR_total / loops;

%% **Step 4: Output Average Errors**
fprintf('%d Times Extra Test Error OLS: %.4f\n', loops, MSE_OLS_avg);
fprintf('%d Times Extra Test Error PCR: %.4f\n', loops, MSE_PCR_avg);

%% **Step 5: Plot Error Comparison**
figure;
bar([MSE_OLS_avg, MSE_PCR_avg], 'FaceColor', 'flat');
set(gca, 'XTickLabel', {'OLS', 'PCR'});
ylabel('Mean Squared Error (MSE)');
title('Average Test MSE Comparison: OLS vs PCR');
grid on;
