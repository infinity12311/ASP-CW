function [PSD] = fARPSD(coeff, sigma_w2, N, dB)

    % **Step 1: 生成频率轴**
    w = linspace(0, 2*pi, N); % 频率点均匀分布
    k = (1:length(coeff))';   % 计算系数索引 (列向量)

    % **Step 2: 计算分母 |1 - Σ a_k e^(-jkw)|**
    E = exp(-1i * (w' * k')); % 计算指数矩阵
    A_w = 1 - (E * coeff(:)); % 计算分母部分

    % **Step 3: 计算 PSD**
    PSD = sigma_w2 ./ abs(A_w).^2; % 按公式计算功率谱密度

    % **Step 4: 是否转换为 dB**
    if strcmpi(dB, 'dB')
        PSD = 10*log10(PSD);
    end
end


