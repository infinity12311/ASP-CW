function [PSD] = fCorrelogram(acf, N, k, dB)
    % **Step 1: 计算频率轴**
    w = linspace(0, 2*pi, N); % 频率向量 (均匀采样)
    
    % **Step 2: 计算指数矩阵**
    E = exp(1i * (w' * k')); % 直接计算指数项，提高计算效率

    % **Step 3: 计算 PSD**
    PSD = real(E * acf); % 利用矩阵乘法计算 PSD

    % **Step 4: 如果需要，转换为 dB**
    if strcmp(dB, 'dB')
        PSD = 10 * log10(abs(PSD)); % 转换为 dB
    end
end

