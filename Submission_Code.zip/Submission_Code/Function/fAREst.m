function [ar_coeff, sigma_2] = fAREst(acf, p)

o = (length(acf) + 1) / 2; % 找到自相关的中心点
r_x = acf(o:o+p);  % 取出相关系数用于构造 Toeplitz 矩阵

% **改进的相关矩阵计算 (Toeplitz 结构)**
R = toeplitz(r_x);  % 直接构造 Toeplitz 矩阵

% **右侧向量 (单位向量)**
l = zeros(p+1, 1);
l(1) = 1;

% **求解 Yule-Walker 方程**
b = R \ l;  % 直接求解线性方程组

% **计算噪声方差**
sigma_2 = 1 / b(1);

% **计算 AR 系数**
ar_coeff = -b(2:end)' * sigma_2;

end

