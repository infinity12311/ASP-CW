clc; clear; close all;

%% **Step 1: Set Signal Parameters**
fs = 1; % Sampling frequency (unit: Hz)
N = 256; % Signal length
t = (0:N-1) / fs; % Time axis
frequencies = [0.3, 0.32]; % Target frequencies
noise_variance = 0.2; % Noise variance

% **Step 2: Generate Noisy Sinusoidal Signal**
noise = 0.3/sqrt(2) * (randn(size(t)) + 1j * randn(size(t))); % Complex Gaussian noise
x = exp(1j * 2 * pi * frequencies(1) * t) + exp(1j * 2 * pi * frequencies(2) * t) + noise;

%% **Step 3: Compute Correlation Matrix**
[X, R] = corrmtx(x, 14, 'mod'); 

%% **Step 4: Compute MUSIC Pseudospectrum**
[S, F] = pmusic(R, 2, [], fs, 'corr'); % 2 signal sources, automatic frequency range

%% **Step 5: Plot MUSIC Pseudospectrum**
figure;
plot(F, 10*log10(S), 'b', 'LineWidth', 2);
grid on;
xlabel('Frequency (Hz)');
ylabel('Power (dB)');
title('MUSIC Spectrum Estimation');
xlim([0.25 0.40]); % Display only the range 0.25 Hz - 0.40 Hz
