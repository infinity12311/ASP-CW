clc; clear; close all;

% **Step 1: Load RRI Data**
load('RRI_data.mat');  % Load RRI data

% **Step 2: Set Parameters**
fsRRI = fsRRI1;  % Sampling frequency (assuming the same for all three trials)
window_sizes = [50, 150]; % Window sizes of 50s and 150s

% **Step 3: Compute Standard Periodogram**
figure;
for i = 1:3
    subplot(3,1,i);
    rri_signal = eval(['xRRI', num2str(i)]); % Select the RRI signal for the current trial
    [Pxx, f] = periodogram(rri_signal, [], [], fsRRI);
    
    plot(f, 10*log10(Pxx), 'b','LineWidth', 1); 
    xlabel('Frequency (Hz)'); ylabel('PSD (dB/Hz)');
    title(['Standard Periodogram - Trial ', num2str(i)]);
    grid on;
end

% **Step 4: Compute Averaged Periodogram (Welch Method)**
for win_idx = 1:length(window_sizes)
    window_length = window_sizes(win_idx) * fsRRI; % Compute window length
    
    figure;
    for i = 1:3
        subplot(3,1,i);
        rri_signal = eval(['xRRI', num2str(i)]); % Select the RRI signal for the current trial
        
        % Compute PSD using Welch method
        [Pxx, f] = pwelch(rri_signal, hamming(window_length), [], [], fsRRI);
        
        plot(f, 10*log10(Pxx), 'b','LineWidth', 1); 
        xlabel('Frequency (Hz)'); ylabel('PSD (dB/Hz)');
        title(['Welch Periodogram PSD (', num2str(window_sizes(win_idx)), 's) - Trial ', num2str(i)]);
        grid on;
    end
end

max_order = 40;  % Maximum AR model order
nf = 2048;  % Number of frequency points

% **Step 5: Iterate Over Three Trials and Estimate AR Spectrum**
figure;
for i = 1:3
    rri_signal = eval(['xRRI', num2str(i)]); % Select the RRI signal for the current trial
    
    % **Step 5.1: Select Optimal Order (Based on Akaike Information Criterion - AIC)**
    best_order = 1;
    best_aic = inf;
    for p = 1:max_order
        [ar_coeff, noise_var] = aryule(rri_signal, p); % Estimate AR model
        aic = length(rri_signal) * log(noise_var) + 2 * p; % Compute AIC
        if aic < best_aic
            best_aic = aic;
            best_order = p;
        end
    end
    
    % **Step 5.2: Compute Final AR PSD**
    [ar_coeff, noise_var] = aryule(rri_signal, best_order);
    [H, f] = freqz(sqrt(noise_var), ar_coeff, nf, fsRRI);
    PSD_AR = abs(H).^2;
    
    % **Step 5.3: Plot AR PSD**
    subplot(3,1,i);
    plot(f, 10*log10(PSD_AR), 'm', 'LineWidth', 1); 
    xlabel('Frequency (Hz)'); ylabel('PSD (dB/Hz)');
    title(['AR Spectrum Estimate - Trial ', num2str(i), ' (Order ', num2str(best_order), ')']);
    grid on;
end
