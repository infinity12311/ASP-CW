%% ========== 参数与初始化 ==========
clear; clc; close all;

% AR(2) 系数与噪声方差
a1 = 0.1; 
a2 = 0.8; 
sigma2 = 0.25;

% LMS 相关
mu_list = [0.05, 0.01];  % 要对比的两个步长
M = 2;                  % 预测器阶数 (这里用 x(n-1), x(n-2))
N = 1000;               % 每次试验的数据长度
numRealization = 100;   % 重复试验次数

% 为存储学习曲线做预分配
% err_store(mu_idx, realization, n)
err_store = zeros(length(mu_list), numRealization, N);

%% ========== 1. 循环不同步长并进行多次试验 ==========
for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);

    for realization = 1:numRealization
        % ===== (a) 生成 AR(2) 数据 =====
        w = sqrt(sigma2)*randn(N,1);  % 白噪声
        x = zeros(N,1);
        x(1) = 0; x(2) = 0;           % 初值可自行指定
        for n = 3:N
            x(n) = a1*x(n-1) + a2*x(n-2) + w(n);
        end

        % ===== (b) LMS 初始化 =====
        wLMS = zeros(M,1);           % 权值向量 [w1, w2]^T
        e_save = zeros(N,1);         % 保存每次迭代的误差

        % ===== (c) 逐点在线学习 =====
        for n = 3:N
            % 输入向量 u(n) = [x(n-1); x(n-2)]
            u = [x(n-1); x(n-2)];
            % 预测输出
            x_hat = wLMS'*u;
            % 误差
            e_n = x(n) - x_hat;
            e_save(n) = e_n;   % 存下第 n 次的误差

            % LMS 更新
            wLMS = wLMS + mu * e_n * u;
        end

        % ===== (d) 记录瞬时误差(平方) =====
        err_store(mu_idx, realization, :) = e_save.^2;
    end
end

%% ========== 2. 画图: 两个subplot对比不同mu的结果 ==========
figure;

% ========== (A) 单次试验(如第一条试验) 的对比 ==========
subplot(1,2,1);
hold on; grid on;
title('Single realisaiton');
xlabel('Iteration (n)'); ylabel('Squared error (dB)');

% mu=0.05 的第一条试验
err_single_mu1 = squeeze(err_store(1,1,:)); % (N x 1)
plot(10*log10(err_single_mu1),'b','LineWidth',1.5);

% mu=0.01 的第一条试验
err_single_mu2 = squeeze(err_store(2,1,:));
plot(10*log10(err_single_mu2),'r','LineWidth',1.5);

legend('\mu=0.05 (single run)','\mu=0.01 (single run)');

% ========== (B) 100次试验平均学习曲线 的对比 ==========
subplot(1,2,2);
hold on; grid on;
title('Average over 100 realisaitons');
xlabel('Iteration (n)'); ylabel('Squared error (dB)');

% mu=0.05 的平均曲线
mean_err_mu1 = mean( squeeze(err_store(1,:,:)), 1 ); % (1 x N)
plot(10*log10(mean_err_mu1),'b','LineWidth',1.5);

% mu=0.01 的平均曲线
mean_err_mu2 = mean( squeeze(err_store(2,:,:)), 1 ); % (1 x N)
plot(10*log10(mean_err_mu2),'r','LineWidth',1.5);

legend('\mu=0.05 (avg)','\mu=0.01 (avg)');
