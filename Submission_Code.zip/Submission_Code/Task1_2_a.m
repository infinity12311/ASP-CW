clc; clear; close all;

%% **Step 1: Load Sunspot Data**
load sunspot.dat; % MATLAB built-in Sunspot data
year = sunspot(:,1);
sunspot_data = sunspot(:,2);
N = length(sunspot_data); % Data length
fs = 1; % Sampling rate (assuming one sample per year)

%% **Step 2: Data Preprocessing**
% Remove mean
sunspot_mean_removed = sunspot_data - mean(sunspot_data);

% Remove trend
sunspot_trend_removed = detrend(sunspot_data);

% Remove both mean & trend
sunspot_mean_trend_removed = detrend(sunspot_mean_removed);

% Log transform + remove mean
log_sunspot = log(sunspot_data + 1); % Avoid log(0) issue
log_sunspot_mean_removed = log_sunspot - mean(log_sunspot);

%% **Step 3: Compute Periodogram**
f_axis = (0:N/2-1) * (fs/N); % Normalized frequency axis

% Original data
X = fft(sunspot_data);
PSD = abs(X(1:N/2)).^2 / N;

% Mean removed data
X_mean_removed = fft(sunspot_mean_removed);
PSD_mean_removed = abs(X_mean_removed(1:N/2)).^2 / N;

% Trend removed data
X_trend_removed = fft(sunspot_trend_removed);
PSD_trend_removed = abs(X_trend_removed(1:N/2)).^2 / N;

% Mean & Trend removed data
X_mean_trend_removed = fft(sunspot_mean_trend_removed);
PSD_mean_trend_removed = abs(X_mean_trend_removed(1:N/2)).^2 / N;

% Log transformed + Mean removed data
X_log = fft(log_sunspot_mean_removed);
PSD_log = abs(X_log(1:N/2)).^2 / N;

%% **Step 4: Plot Figures**
figure;

% (a) Original vs Mean-removed data (Time Domain)
subplot(2,3,1);
plot(year, sunspot_data, 'b', 'LineWidth', 1.5); hold on;
plot(year, sunspot_mean_removed, 'r', 'LineWidth', 1.5);
xlabel('Year'); ylabel('Magnitude');
title('Original vs Mean-removed');
legend('sunspot', 'sunspot-mean-removed');
grid on;

% (b) Original vs Trend-removed data (Time Domain)
subplot(2,3,2);
plot(year, sunspot_data, 'b', 'LineWidth', 1.5); hold on;
plot(year, sunspot_trend_removed, 'r', 'LineWidth', 1.5);
xlabel('Year'); ylabel('Magnitude');
title('Original vs Trend-removed');
legend('sunspot', 'sunspot-trend-removed');
grid on;

% (c) Original vs Mean & Trend removed data (Time Domain)
subplot(2,3,3);
plot(year, sunspot_data, 'b', 'LineWidth', 1.5); hold on;
plot(year, sunspot_mean_trend_removed, 'r', 'LineWidth', 1.5);
xlabel('Year'); ylabel('Magnitude');
title('Original vs Mean-Trend-removed');
legend('sunspot', 'sunspot-mean-trend-removed');
grid on;

% (e) Original vs Mean-removed data (Frequency Domain)
subplot(2,3,4);
plot(f_axis, 10*log10(PSD), 'b', 'LineWidth', 1.5); hold on;
plot(f_axis, 10*log10(PSD_mean_removed), 'r', 'LineWidth', 1.5);
xlabel('Frequency (cycles/year)'); ylabel('Magnitude (dB)');
title('PSD: Original vs Mean-removed');
legend('PSD', 'PSD-mean-removed');
grid on;

% (f) Original vs Trend-removed data (Frequency Domain)
subplot(2,3,5);
plot(f_axis, 10*log10(PSD), 'b', 'LineWidth', 1.5); hold on;
plot(f_axis, 10*log10(PSD_trend_removed), 'r', 'LineWidth', 1.5);
xlabel('Frequency (cycles/year)'); ylabel('Magnitude (dB)');
title('PSD: Original vs Trend-removed');
legend('PSD', 'PSD-trend-removed');
grid on;

% (g) Original vs Mean & Trend removed data (Frequency Domain)
subplot(2,3,6);
plot(f_axis, 10*log10(PSD), 'b', 'LineWidth', 1.5); hold on;
plot(f_axis, 10*log10(PSD_mean_trend_removed), 'r', 'LineWidth', 1.5);
xlabel('Frequency (cycles/year)'); ylabel('Magnitude (dB)');
title('PSD: Original vs Mean-Trend-removed');
legend('PSD', 'PSD-mean-trend-removed');
grid on;

figure;
% (d) Original vs Log transformed & Mean removed data (Time Domain)
subplot(3,1,1);
plot(year, sunspot_data, 'b', 'LineWidth', 1.5);
xlabel('Year'); ylabel('Magnitude');
title('Original sunspot data');
legend('sunspot');
grid on;

subplot(3,1,2);
plot(year, log_sunspot, 'r', 'LineWidth', 1.5);
xlabel('Year'); ylabel('Magnitude');
title('Log data');
legend('log-sunspot');
grid on;

subplot(3,1,3);
plot(year, log_sunspot_mean_removed, 'r', 'LineWidth', 1.5);
xlabel('Year'); ylabel('Magnitude');
title('Log Mean-removed data');
legend('log-sunspot-mean-removed');
grid on;

figure;
% (h) Original vs Log transformed & Mean removed data (Frequency Domain)
plot(f_axis, 10*log10(PSD), 'b', 'LineWidth', 1.5); hold on;
plot(f_axis, 10*log10(PSD_log), 'r', 'LineWidth', 1.5);
xlabel('Frequency (cycles/year)'); ylabel('Magnitude (dB)');
title('PSD: Original vs Log Mean-removed');
legend('PSD', 'PSD-log-mean-removed');
grid on;
