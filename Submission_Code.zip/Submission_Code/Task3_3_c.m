clc; clear; close all;

%% ========== 1. 生成FM信号(与3.2相同) ==========
N = 1500;        % 信号长度
fs = 1000;       % 采样频率
sigma2 = 0.05;   % 噪声方差
mu = 1;          % DFT-CLMS 学习率(参考Widrow等人的结论)

% (a) 构造瞬时频率 f(n)
f = zeros(1, N);
for n = 1:N
    if n <= 500
        f(n) = 100;
    elseif n <= 1000
        f(n) = 100 + (n - 500)/2;
    else
        f(n) = 100 + ((n - 1000)/25)^2;
    end
end

% (b) 计算相位 phi(n) = \sum f(n)*(2π/fs)
phi = cumsum(f) * (2*pi/fs);

% (c) 生成FM信号 y(n) = exp(j*phi(n)) + 噪声
eta = sqrt(sigma2/2) * (randn(1, N) + 1j*randn(1, N));
y = exp(1j * phi) + eta;

%% ========== 2. 构造 DFT-CLMS 的输入向量 x(n) ==========
% 根据式 (41): x(n) = (1/N)*[ 1, e^{j2πn/N}, e^{j4πn/N}, ..., e^{j2π(N-1)n/N} ]^T
% 注: 1/N 的因子是否放在 x(n) 或权值 w(n) 中, 文献中写法不一, 这里按公式(41)实现
M = N;  % 输入向量维度 = N
xFun = @(n) (1/N)*exp(1j*2*pi*(0:M-1)*n/N).';  % 返回 M×1 列向量

%% ========== 3. 初始化 DFT-CLMS 参数 ==========
wMat = zeros(M, N+1);  % 每个时刻 n 都有一个长度为 M 的权值向量
e = zeros(1, N);       % 误差
% 初始权值设为0 (Widrow等人指出: 从 w(0)=0 开始, mu=1, 最终收敛到DFT解)

%% ========== 4. 进行 DFT-CLMS 迭代 ==========
for n = 1:N
    x_n = xFun(n-1);          % 注意: 时刻 n 对应信号 y(n), 但指数里用 n-1, 保持一致
    y_hat = wMat(:, n)' * x_n;  % 预测输出
    e(n) = y(n) - y_hat;        % 误差
    % 更新权值
    wMat(:, n+1) = wMat(:, n) + mu * conj(e(n)) * x_n;
end

%% ========== 5. 绘制时间-频率图 (|w(k,n)|) ==========
% wMat(k,n) 表示在第n次迭代后, 第k个“频率”上的权值
% 我们只用 1~N 次迭代后 (即 wMat(:,2~N+1)) 的值来绘图
W_mag = abs(wMat(:,2:end));  % 大小为 M×N

% 频率索引: k=0~N-1 => 实际频率 freq_k = (k*fs)/N
freqAxis = (0:M-1)*(fs/N);
timeAxis = 1:N;  % 离散时间

figure;
imagesc(timeAxis, freqAxis, W_mag);
axis xy;  % 让频率从小到大
xlabel('Time index n');
ylabel('Frequency (Hz)');
title('Time-Frequency Diagram (Magnitude of w(k,n)) - DFT-CLMS');
colorbar;
colormap jet;

%% ========== 6. 注释: 为什么与真正功率谱不同? =========%
% 1) DFT-CLMS 追踪的是"信号在傅里叶基下的线性组合系数"
%    并不直接估计"瞬时功率谱"。
% 2) 当 mu=1 并从0开始迭代, 最终收敛到整段信号的DFT解, 类似一次全局离散傅里叶变换。
%    这无法体现真正随时间变化的功率分布。
% 3) 若要估计非平稳信号的瞬时频率轨迹, 需要如 AR(1)-CLMS 或 STFT等时频方法,
%    而 DFT-CLMS 提供的只是"每个时刻下的DFT基系数更新", 其物理含义更接近
%    "信号在固定傅里叶基上的逐点拟合", 不等于瞬时功率谱。
