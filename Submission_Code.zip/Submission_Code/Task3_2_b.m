clc; clear; close all;

% 参数设置
N = 1500;       % 信号长度
fs = 1000;      % 采样频率
mu = 0.1;      % CLMS 学习率
sigma_eta = sqrt(0.05);  % 噪声标准差

% 生成频率变化 f(n)
f = zeros(1, N);
for n = 1:N
    if n <= 500
        f(n) = 100;
    elseif n <= 1000
        f(n) = 100 + (n - 500) / 2;
    else
        f(n) = 100 + ((n - 1000) / 25).^2;
    end
end

% 计算相位 phi(n) = 累积分 f(n)
phi = cumsum(f) * (2 * pi / fs);

% 生成 FM 信号 y(n) = exp(j*phi(n)) + eta(n)
eta = (randn(1, N) + 1j * randn(1, N)) * sigma_eta / sqrt(2);
y = exp(1j * phi) + eta;

% 初始化 CLMS 参数
order = 1; % AR(1) 模型
h_CLMS = zeros(order, N); % CLMS 权重
error_CLMS = zeros(1, N); % 误差存储
H = zeros(1024, N); % 瞬时功率谱矩阵

% CLMS 迭代计算 AR(1) 系数并计算瞬时功率谱
for n = 2:N
    x_segment = y(n-1); % 仅使用前一个样本
    y_hat_CLMS = h_CLMS(n-1)' * x_segment; % 预测输出
    error_CLMS(n) = y(n) - y_hat_CLMS; % 误差计算
    h_CLMS(n) = h_CLMS(n-1) + mu * conj(error_CLMS(n)) * x_segment; % 更新权重

    % 计算瞬时功率谱
    [h, w] = freqz(1, [1, -conj(h_CLMS(n))], 1024, fs);
    H(:, n) = abs(h).^2;
end

% 处理功率谱数据，去除异常值
medianH = 50 * median(median(H));
H(H > medianH) = medianH;

% 绘制时频图（Time-Frequency Spectrum）
figure;
imagesc(1:N, w, 10*log10(H));
axis xy;
xlabel('Time Index n');
ylabel('Frequency (Hz)');
title('Time-Frequency Spectrum using CLMS');
colorbar;
colormap jet;
