%% ========== 参数与初始化 ==========
clear; clc; close all;

% AR(2) 系数 (与题目一致)
a1 = 0.1; 
a2 = 0.8; 
sigma2_eta = 0.25;  % 噪声方差

% Leaky LMS 相关
mu = 0.05;          % 步长
gamma_list = [0.01, 0.1, 0.5];  % 不同的泄漏系数做对比
M = 2;              % 预测器阶数 (x(n-1), x(n-2))
N = 1000;           % 数据长度
numReal = 100;       % 重复试验次数
steadyStart = 901;        % 稳态区起始点(取最后100点)

% 用于记录最终稳态权值
w_final_all = zeros(length(gamma_list), numReal, M);

%% ========== 1. 多次试验, 实现 Leaky LMS ==========
for g_idx = 1:length(gamma_list)
    gamma = gamma_list(g_idx);

    for realization = 1:numReal
        % --- (a) 生成 AR(2) 数据 ---
        w_noise = sqrt(sigma2_eta)*randn(N,1);
        x = zeros(N,1);
        x(1)=0; x(2)=0; % 初值
        for n = 3:N
            x(n) = a1*x(n-1) + a2*x(n-2) + w_noise(n);
        end

        % --- (b) 初始化滤波器 ---
        wLeaky = zeros(M,1);  % [w1; w2]

        % --- (c) 逐点更新 (Leaky) ---
        for n=3:N
            u_n = [x(n-1); x(n-2)];
            x_hat = wLeaky' * u_n;
            e_n = x(n) - x_hat;

            % Leaky LMS 更新:
            wLeaky = (1 - mu*gamma)*wLeaky + mu * e_n * u_n;
        end

        % --- (d) 记录最终稳态权值(如最后一步) ---
        w_final_all(g_idx, realization, :) = wLeaky;
    end
end

%% ========== 2. 对比结果并输出平均稳态系数 ==========
true_coeff = [a1, a2];
fprintf('\n=== 真实AR(2)系数: a1=%.3f, a2=%.3f ===\n', a1, a2);

for g_idx = 1:length(gamma_list)
    gamma = gamma_list(g_idx);
    w_final_mean = mean( squeeze(w_final_all(g_idx,:,:)), 1 );
    fprintf('\n--- 泄漏系数 gamma = %.4f ---\n', gamma);
    fprintf('平均稳态估计: [w1, w2] = [%.4f, %.4f]\n', ...
            w_final_mean(1), w_final_mean(2));
    fprintf('与真实值差异: [%.4f, %.4f]\n', ...
            w_final_mean(1)-a1, w_final_mean(2)-a2);
end
