clc; clear; close all;
addpath('./Function/');

%% **Step 1: Generate Test Signals**
N = 256; % Signal length
fs = 200; % Sampling frequency (Hz)
t = (0:N-1)/fs; % Time axis

% (1) White Gaussian Noise (WGN)
wgn_signal = randn(N,1);

% (2) Noisy Sinusoidal Signal
sin_signal = 0.6*sin(2*pi*35*t) + sin(2*pi*50*t) + 0.5*randn(1, length(t)); % Sine wave + noise

% (3) Filtered White Gaussian Noise (Filtered WGN)
[b, a] = butter(4, 0.2, 'low'); % 4th order low-pass filter, cutoff frequency 0.2 * fs/2
filtered_wgn = filter(b, a, wgn_signal);

% Store signals
signals = {wgn_signal, sin_signal, filtered_wgn};
signal_names = {'White Gaussian Noise (WGN)', ...
                'Noisy Sinusoidal Signal', ...
                'Filtered WGN'};

%% **Step 2: Compute Biased and Unbiased ACF**
acf_biased_all = {};
acf_unbiased_all = {};

for i = 1:length(signals)
    x = signals{i};
    
    % Compute Biased and Unbiased ACF using fACF
    [acf_biased, k_biased] = fACF(x, 'biased');
    [acf_unbiased, k_unbiased] = fACF(x, 'unbiased');
    
    % Store results
    acf_biased_all{i} = acf_biased;
    acf_unbiased_all{i} = acf_unbiased;
    
    % Plot ACF
    figure;
    subplot(2,1,1)
    plot(k_biased, acf_biased, 'b', 'LineWidth', 1.5); 
    xlabel('Lag');
    ylabel('ACF');
    title(['Biased ACF - ', signal_names{i}]);
    legend('Biased ACF');
    grid on;

    subplot(2,1,2)
    plot(k_unbiased, acf_unbiased, 'r', 'LineWidth', 1.5);
    xlabel('Lag');
    ylabel('ACF');
    title(['Unbiased ACF - ', signal_names{i}]);
    legend('Unbiased ACF');
    grid on;
end

%% **Step 3: Compute Correlogram PSD**
f = linspace(0, fs/2, N/2); % Frequency axis
psd_biased_all = {};
psd_unbiased_all = {};

for i = 1:length(signals)
    % Compute Correlogram PSD using fCorrelogram
    [PSD_biased] = fCorrelogram(acf_biased_all{i}, N, k_biased, '');
    [PSD_unbiased] = fCorrelogram(acf_unbiased_all{i}, N, k_unbiased, '');

    % Store PSD results
    psd_biased_all{i} = PSD_biased;
    psd_unbiased_all{i} = PSD_unbiased;
    
    % **Plot PSD (without log transformation)**
    figure;
    plot(f, real(PSD_biased(1:N/2)), 'b', 'LineWidth', 1.5); hold on;
    plot(f, real(PSD_unbiased(1:N/2)), 'r', 'LineWidth', 1.5);
    xlabel('Frequency (Hz)');
    ylabel('Power Spectral Density / Hz');
    title(['Correlogram PSD (Linear Scale) - ', signal_names{i}]);
    legend('Biased PSD', 'Unbiased PSD');
    grid on;
end
