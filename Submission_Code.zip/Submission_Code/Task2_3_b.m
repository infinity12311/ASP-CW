clc; clear; close all;

% 参数设置
N = 1000; % 信号长度
mu = 0.01; % 学习率
num_realizations = 100; % 实验次数
delta = 3; % 固定延迟 Δ=3
M_values = 1:20; % 预测器阶数 M 从 1 到 20

% 预分配存储 MSPE 结果
MSPE_results = zeros(length(M_values), 1);

% 遍历不同的 M 值
for m_idx = 1:length(M_values)
    M = M_values(m_idx);
    MSPE_all = zeros(N, num_realizations); % 存储误差信号

    for realization = 1:num_realizations
        % 生成信号
        n = (0:N-1)';
        x = sin(0.01 * pi * n); % 真实信号
        v = randn(N,1); % 白噪声
        eta = v + 0.5 * [zeros(2,1); v(1:end-2)]; % 颜色噪声
        s = x + eta; % 噪声污染信号

        % 自适应滤波初始化
        w = zeros(M,1); % 线性预测器权重
        x_hat = zeros(N,1); % 估计的干净信号
        e = zeros(N,1); % 误差信号

        % LMS 迭代
        for n = M+delta:N
            u = s(n-delta:-1:n-delta-M+1);
            x_hat(n) = w' * u;
            e(n) = s(n) - x_hat(n);
            w = w + mu * e(n) * u;
        end

        % 存储误差信号
        MSPE_all(:, realization) = x-x_hat;
    end

    % 计算均方预测误差 (MSPE)
    MSPE_results(m_idx) = mean(mean(MSPE_all.^2));
end

% 转换 MSPE 为 dB
MSPE_dB = 10 * log10(MSPE_results);

% 画 MSPE vs Order M 图
figure;
plot(M_values, MSPE_dB, 'ro-', 'LineWidth', 1.5, 'MarkerSize', 6);

% 设置图例和标签
xlabel('Order M');
ylabel('MSPE (dB)');
title('MSPE vs. Filter Order M (Fixed \Delta = 3)');
grid on;
