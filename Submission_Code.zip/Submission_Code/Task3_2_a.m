clc; clear; close all;

% 参数设置
N = 1500;       % 信号长度
fs = 3000;      % 采样频率
sigma_eta = sqrt(0.05);  % 噪声标准差

% 生成频率变化 f(n)
f = zeros(1, N);
for n = 1:N
    if n <= 500
        f(n) = 100;
    elseif n <= 1000
        f(n) = 100 + (n - 500) / 2;
    else
        f(n) = 100 + ((n - 1000) / 25).^2;
    end
end

% 计算相位 phi(n) = 累积分 f(n)
phi = cumsum(f) * (2 * pi / fs);

% 生成 FM 信号 y(n) = exp(j*phi(n)) + eta(n)
eta = (randn(1, N) + 1j * randn(1, N)) * sigma_eta / sqrt(2);
y = exp(1j * phi) + eta;

% 计算 AR(1) 系数
order = 1; % AR(1) 模型
a = aryule(y, order);

% 计算功率谱密度
[h, w] = freqz(1, a, N, fs);
power_spectrum = abs(h).^2;

% 绘制频率变化 f(n)
figure;
subplot(3,1,1);
plot(1:N, f, 'b', 'LineWidth', 1.5);
xlabel('Time index n');
ylabel('Frequency f(n)');
title('Instantaneous Frequency of FM Signal');
grid on;

% 绘制 FM 信号时域波形（实部）
subplot(3,1,2);
plot(1:N, real(y), 'r', 'LineWidth', 1);
xlabel('Time index n');
ylabel('Re(y[n])');
title('Real Part of FM Signal');
grid on;

% 绘制功率谱密度
subplot(3,1,3);
plot(w, 10*log10(power_spectrum), 'k', 'LineWidth', 1.5);
xlabel('Frequency (Hz)');
ylabel('Power Spectrum (dB)');
title('Power Spectrum of Estimated AR(1) Model');
grid on;

