clear; clc; close all;

%% ========== 参数与初始化 ==========
% AR(2) 系数
a1 = 0.1; 
a2 = 0.8; 
sigma2_eta = 0.25;  % 噪声方差

% Leaky LMS 相关
mu_list = [0.01, 0.05];  % 不同的学习率
gamma_list = [0.01, 0.1, 0.5];  % 不同的泄漏系数
M = 2;              % 预测器阶数
N = 1500;           % 数据长度
numReal = 50;       % 试验次数

% 存储所有试验的完整权重轨迹
w_history_all = zeros(length(mu_list), length(gamma_list), numReal, M, N);

%% ========== 1. 多次试验, 计算 Leaky LMS 系数轨迹 ==========
for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);
    
    for g_idx = 1:length(gamma_list)
        gamma = gamma_list(g_idx);

        for realization = 1:numReal
            % --- 生成 AR(2) 数据 ---
            w_noise = sqrt(sigma2_eta)*randn(N,1);
            x = zeros(N,1);
            x(1)=0; x(2)=0; % 初值
            for n = 3:N
                x(n) = a1*x(n-1) + a2*x(n-2) + w_noise(n);
            end

            % --- 初始化滤波器 ---
            wLeaky = zeros(M,1);  

            % --- 逐点更新 (Leaky LMS) ---
            for n = 3:N
                u_n = [x(n-1); x(n-2)];
                x_hat = wLeaky' * u_n;
                e_n = x(n) - x_hat;

                % Leaky LMS 更新:
                wLeaky = (1 - mu*gamma) * wLeaky + mu * e_n * u_n;

                % 记录当前时间步的权重
                w_history_all(mu_idx, g_idx, realization, :, n) = wLeaky;
            end
        end
    end
end

%% ========== 2. 绘制所有试验的系数轨迹 ==========
figure;
tiledlayout(length(mu_list), length(gamma_list));

time_axis = 1:N; % 时间步长

for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);
    
    for g_idx = 1:length(gamma_list)
        gamma = gamma_list(g_idx);
        
        % 画图
        nexttile;
        hold on;
        
        % 遍历所有试验并绘制所有轨迹
        for realization = 1:numReal
            w1_traj = squeeze(w_history_all(mu_idx, g_idx, realization, 1, :));
            w2_traj = squeeze(w_history_all(mu_idx, g_idx, realization, 2, :));

            plot(time_axis, w1_traj, 'b', 'LineWidth', 0.5, 'HandleVisibility', 'off', 'Color', [0 0 1 0.1]); % 透明蓝色
            plot(time_axis, w2_traj, 'r', 'LineWidth', 0.5, 'HandleVisibility', 'off', 'Color', [1 0 0 0.1]); % 透明红色
        end

        % 添加代表性曲线用于 legend
        h1 = plot(time_axis, squeeze(mean(w_history_all(mu_idx, g_idx, :, 1, :), 3)), 'b', 'LineWidth', 1.5, 'DisplayName', 'Esta_1');
        h2 = plot(time_axis, squeeze(mean(w_history_all(mu_idx, g_idx, :, 2, :), 3)), 'r', 'LineWidth', 1.5, 'DisplayName', 'Esta_2');

        % 真实系数参考线
        h3 = yline(a1, '-b', 'LineWidth', 3, 'DisplayName', 'a_1');
        h4 = yline(a2, '-r', 'LineWidth', 3, 'DisplayName', 'a_2');

        % 设置标题和标签
        title(['Leaky LMS (\mu = ', num2str(mu), ', \gamma = ', num2str(gamma), ')']);
        xlabel('Time Step');
        ylabel('Estimate');
        
        % 只在第一个子图中添加 legend，避免重复
        legend([h1, h2, h3, h4]);
        
        hold off;
    end
end

sgtitle('Leaky LMS Coefficient Estimation for Different \mu and \gamma');
