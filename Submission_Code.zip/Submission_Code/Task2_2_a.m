%% ========== 1. 参数设置 ==========
clear; clc; close all;

N = 1000;                  % 数据长度 (与原N相同)
sigma2_v = 0.5;            % 噪声方差 (原先 sqrt(1/2) -> sqrt(sigma2_v))
w_true = 0.9;              % MA(1)系统实际系数(仅需0.9, 原逻辑只估计一个系数)
mu_fixed_list = [0.01, 0.1];% 固定步长LMS的两个步长 (对应原mu=0.01, mu_alt=0.1)
rho = 0.0003;              % GASS步长更新的学习率 (保持与原值相同)
alpha = 0.5;               % Ang & Farhang算法中的衰减因子(原来硬编码0.5)
mu_init = 0.01;            % GASS初始步长 (对应原mu=0.01)
M = 1;                     % 滤波器阶数 (原为1)
num_trials = 100;                   % 进行K次蒙特卡洛试验

%% ========== 2. 为多次试验结果准备累加容器 ==========
w_B_Avg = zeros(M, N+1);         % Benveniste
w_A_Avg = zeros(M, N+1);         % Ang &Farhang
w_M_Avg = zeros(M, N+1);         % Matthews
w_LMS_Avg_1 = zeros(M, N+1);         % 标准LMS (mu_fixed_list(1))
w_LMA_Avg_2 = zeros(M, N+1); % 标准LMS (mu_fixed_list(2))

%% ========== 3. 开始蒙特卡洛试验：重复K次 ==========
for k = 1:num_trials
    
    % ------ (a) 生成MA(1)过程信号 x(n) ------
    v = sqrt(sigma2_v) * randn(N,1);  % 驱动白噪声
    x = zeros(N,1);
    for n = 2:N
        % x(n) = 0.9 * v(n-1) + v(n)  (与原eta逻辑一致)
        x(n) = w_true * v(n-1) + v(n);
    end
    
    % ------ (b) Benveniste方法 ------
    w_B = zeros(M, N+1); 
    mu_B = zeros(1, N+1);
    e_B = zeros(1, N+1);
    phi_B = zeros(M, N+1);
    mu_B(M+2) = mu_init;  % 初始步长

    for n = (M+2):N
        % 对应输入u_n只需 v(n-1), 因为M=1
        u_n = v(n-1);
        d_n = x(n);
        w_n = w_B(:, n);
        mu_n = mu_B(n);
        
        % 误差
        e_n = d_n - w_n' * u_n;
        e_B(n) = e_n;
        
        % 权值更新
        w_B(:, n+1) = w_n + mu_n * e_n * u_n;
        
        % phi(n) 更新
        u_nm1 = v(n-2);    % 比u_n滞后1步
        phi_n_1 = phi_B(:, n-1);
        e_nm1 = e_B(n-1);
        
        % Benveniste公式: phi(n) = [I - mu(n-1)*u(n-1)*u(n-1)^T]*phi(n-1) + e(n-1)*u(n-1)
        phi_n = (eye(M) - mu_B(n-1)*(u_nm1*u_nm1')) * phi_n_1 + e_nm1*u_nm1;
        phi_B(:, n) = phi_n;
        
        % 步长更新
        mu_B(n+1) = mu_n + rho * e_n * (u_n') * phi_n;
    end
    
    % ------ (c) Ang &Farhang方法 ------
    w_A = zeros(M, N+1);
    mu_A = zeros(1, N+1);
    e_A = zeros(1, N+1);
    phi_A = zeros(M, N+1);
    mu_A(M+2) = mu_init;  % 初始步长

    for n = (M+2):N
        u_n = v(n-1);
        d_n = x(n);
        w_n = w_A(:, n);
        mu_n = mu_A(n);
        
        e_n = d_n - w_n' * u_n;
        e_A(n) = e_n;
        
        w_A(:, n+1) = w_n + mu_n * e_n * u_n;
        
        % 更新phi
        u_nm1 = v(n-2);
        phi_n_1 = phi_A(:, n-1);
        e_nm1 = e_A(n-1);
        
        % Farhang: phi(n) = alpha*phi(n-1) + e(n-1)*u(n-1)
        phi_n = alpha * phi_n_1 + e_nm1 * u_nm1;
        phi_A(:, n) = phi_n;
        
        mu_A(n+1) = mu_n + rho * e_n * (u_n') * phi_n;
    end
    
    % ------ (d) Matthews方法 ------
    w_M = zeros(M, N+1);
    mu_M = zeros(1, N+1);
    e_M = zeros(1, N+1);
    phi_M = zeros(M, N+1);
    mu_M(M+2) = mu_init;

    for n = (M+2):N
        u_n = v(n-1);
        d_n = x(n);
        w_n = w_M(:, n);
        mu_n = mu_M(n);

        e_n = d_n - w_n' * u_n;
        e_M(n) = e_n;
        
        w_M(:, n+1) = w_n + mu_n * e_n * u_n;
        
        % Matthews: phi(n) = e(n-1)*u(n-1)
        u_nm1 = v(n-2);
        e_nm1 = e_M(n-1);
        phi_n = e_nm1 * u_nm1;
        phi_M(:, n) = phi_n;
        
        mu_M(n+1) = mu_n + rho * e_n * (u_n') * phi_n;
    end
    
    % ------ (e) 标准LMS (步长=0.01) ------
    w_N = zeros(M, N+1);
    mu_N = zeros(1, N+1);
    e_N = zeros(1, N+1);
    mu_N(M+2) = mu_fixed_list(1);  % 第一个固定步长

    for n = (M+2):N
        u_n = v(n-1);
        d_n = x(n);
        w_n = w_N(:, n);
        mu_n_ = mu_N(n);
        
        e_n_ = d_n - w_n' * u_n;
        e_N(n) = e_n_;
        
        w_N(:, n+1) = w_n + mu_n_ * e_n_ * u_n;
        mu_N(n+1) = mu_n_;
    end
    
    % ------ (f) 标准LMS (步长=0.1) ------
    w_N_Altered = zeros(M, N+1);
    mu_NA = zeros(1, N+1);
    e_NA = zeros(1, N+1);
    mu_NA(M+2) = mu_fixed_list(2); % 第二个固定步长

    for n = (M+2):N
        u_n = v(n-1);
        d_n = x(n);
        w_n = w_N_Altered(:, n);
        mu_n_ = mu_NA(n);
        
        e_n_ = d_n - w_n' * u_n;
        e_NA(n) = e_n_;
        
        w_N_Altered(:, n+1) = w_n + mu_n_ * e_n_ * u_n;
        mu_NA(n+1) = mu_n_;
    end
    
    % ------ 将本次试验结果累加 ------
    w_B_Avg = w_B_Avg + w_B;
    w_A_Avg = w_A_Avg + w_A;
    w_M_Avg = w_M_Avg + w_M;
    w_LMS_Avg_1 = w_LMS_Avg_1 + w_N;
    w_LMA_Avg_2 = w_LMA_Avg_2 + w_N_Altered;
end

%% ========== 4. K次试验结果取平均 ==========
w_B_Avg = w_B_Avg / num_trials;
w_A_Avg = w_A_Avg / num_trials;
w_M_Avg = w_M_Avg / num_trials;
w_LMS_Avg_1 = w_LMS_Avg_1 / num_trials;
w_LMA_Avg_2 = w_LMA_Avg_2 / num_trials;

%% ========== 5. 绘图：比较 w(n) 与 w_true=0.9 的差值 ==========
figure; hold on; grid on;
plot(w_true - w_LMS_Avg_1(1,:), '-b', 'LineWidth', 1);
plot(w_true - w_LMA_Avg_2(1,:), '-r', 'LineWidth', 1);
plot(w_true - w_M_Avg(1,:), '-g', 'LineWidth', 1);
plot(w_true - w_A_Avg(1,:), '-m', 'LineWidth', 1);
plot(w_true - w_B_Avg(1,:), '-c', 'LineWidth', 1);

xlim([0, N]);
legend(['Standard LMS, \mu=' num2str(mu_fixed_list(1))], ...
       ['Standard LMS, \mu=' num2str(mu_fixed_list(2))], ...
       ['Matthews, \mu_{init}=' num2str(mu_init)], ...
       ['Ang & Farhang, \mu_{init}=' num2str(mu_init)], ...
       ['Benveniste, \mu_{init}=' num2str(mu_init)], ...
       'Location','best');
xlabel('Step n');
ylabel('Weight Error = 0.9 - w(n)');
title('Comparison of LMS and GASS (MA(1) system)');

