% ============ 1. 参数设置 ================
clear; clc; close all;

N = 10000;              % 总长度
a1 = 0.1; a2 = 0.8;     % AR(2) 系数
sigma2 = 0.25;          % 噪声方差
w = sqrt(sigma2)*randn(N,1);  % 白噪声

% ============ 2. 生成 AR(2) 数据 ==========
x = zeros(N,1);
% 给定初值(可为0), 然后递推
x(1) = 0;
x(2) = 0;
for n = 3:N
    x(n) = a1*x(n-1) + a2*x(n-2) + w(n);
end

% 舍弃初始的 500 个样本，以去除初始状态影响
x = x(501:end);
N_new = length(x);

% ============ 3. 构造输入矩阵并估计 R =======
% 对于 n = 3 到 N_new，令输入向量 x_in(n) = [x(n-1); x(n-2)]
% 简化起见，这里用矩阵批量构造：
X = [ x(2:end), x(1:end-1) ];  % 大小 (N_new-1) x 2
R_est = (X'*X) / (N_new-1);    % 时间平均法估计自相关矩阵

disp('--- 数值模拟估计的自相关矩阵 R_est ---');
disp(R_est);

% ============ 4. 理论矩阵与最大特征值 =========
% (a) 理论推导得到的 R
r0 = 0.9259;
r1 = 0.4629;
R_theory = [r0, r1; r1, r0];

disp('--- 理论推导的自相关矩阵 R_theory ---');
disp(R_theory);

% (b) 计算 R_est 的最大特征值
eigvals_est = eig(R_est);
lambda_max_est = max(eigvals_est);
mu_upper_est = 2 / lambda_max_est;

disp('--- 由数值估计 R_est 得到的步长稳定范围 ---');
disp(['0 < mu < ', num2str(mu_upper_est)]);

% (c) 也可直接计算 R_theory 的最大特征值
eigvals_th = eig(R_theory);
lambda_max_th = max(eigvals_th);
mu_upper_th = 2 / lambda_max_th;

disp('--- 由理论 R_theory 得到的步长稳定范围 ---');
disp(['0 < mu < ', num2str(mu_upper_th)]);
