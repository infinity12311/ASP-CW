clc; clear; close all;
addpath('./Function/');

%% **Step 1: Set Signal Parameters**
N = 1000; % Total number of samples
N_discard = 500; % Discard the first 500 samples
p_values = 2:1:14; % Select model orders p = 2, 4, ..., 14
fs = 1; % Sampling rate (assuming normalized unit)

% **AR(4) process coefficients**
a = [2.76, -3.81, 2.65, -0.92]; 
sigma_2 = 1; % Noise variance
% rng(21); % Set random seed

%% **Step 2: Generate AR(4) Process Data**
x = filter(1, [1, -a], sqrt(sigma_2) * randn(N,1)); % Generate AR(4) data
x = x(N_discard+1:end); % Discard the first 500 samples
N = length(x); % Update effective data length

%% **Compute True Power Spectral Density (PSD)**
nf = 1024; % Number of frequency sampling points
w = linspace(0, fs/2, nf/2+1); % Frequency axis
PSD_true = fARPSD(a, sigma_2, nf, ''); % Compute true PSD

%% **Compute Biased ACF**
[acf_biased, k] = fACF(x, 'biased');

%% **Step 3: Fit AR Model with Different p Values**
figure;
hold on;
legend_entries = {};
error = zeros(1, length(p_values)); % Store mean square error (MSE)

for i = 1:length(p_values)
    p = p_values(i);
    
    % Compute PSD of AR(p) model
    [AR_Coeff_Est, sigma_2_Est] = fAREst(acf_biased, p);
    PSD_estimated = fARPSD(AR_Coeff_Est, sigma_2_Est, nf, '');
    error(i) = mean((PSD_true - PSD_estimated) .^2); % Compute MSE
    
    % Plot PSD for different orders
    plot(w, 10*log10(PSD_estimated(1:nf/2+1)), 'LineWidth', 1.2);
    legend_entries{end+1} = ['AR(', num2str(p), ')']; % Update legend
end

% **Step 4: Plot True PSD**
plot(w, 10*log10(PSD_true(1:nf/2+1)), 'k', 'LineWidth', 2); % Bold true curve
grid on;
xlabel('Frequency (Hz)');
ylabel('Power Spectral Density (dB)');
title('PSD Estimation using AR Model (Different Orders)');
legend([legend_entries, 'True AR(4) Model'], 'Location', 'Best'); % Update legend

%% **Step 5: Plot Optimal Result**
figure;
subplot(2,1,1);
semilogy(p_values, error, '-ob', 'LineWidth', 1.5);
xlabel('p'); 
ylabel('Mean Square Error','FontSize',12,'interpreter','latex'); 
grid on;

% Select model order with the minimum MSE
[~, best_p_idx] = min(error);
best_p = p_values(best_p_idx);

[AR_Coeff_Est, sigma_2_Est] = fAREst(acf_biased, best_p); % Best estimated PSD
PSD_estimated_dB = fARPSD(AR_Coeff_Est, sigma_2_Est, nf, 'dB');
PSD_true_dB = fARPSD(a, sigma_2, nf, 'dB'); % Compute true PSD

subplot(2,1,2);
plot(w, PSD_true_dB(1:nf/2+1), '-b', 'LineWidth', 1.5);
hold on;
plot(w, PSD_estimated_dB(1:nf/2+1), '-r', 'LineWidth', 1.5);
grid on;
xlabel('Frequency (Hz)');
ylabel('Power Spectral Density (dB)');
legend('True PSD', ['Best Estimated PSD (p=' num2str(best_p) ')']);

%% **Step 6: Compute PSD for Long Data Sample N=10000**
% Generate AR(4) Process Data**
x = filter(1, [1, -a], sqrt(sigma_2) * randn(10*N,1)); % Generate AR(4) data
x = x(N_discard+1:end); % Discard the first 500 samples
N = length(x); % Update effective data length

% Compute True Power Spectral Density (PSD)**
nf = 1024; % Number of frequency sampling points
w = linspace(0, fs/2, nf/2+1); % Frequency axis
PSD_true = fARPSD(a, sigma_2, nf, ''); % Compute true PSD

% Compute Biased ACF**
[acf_biased, k] = fACF(x, 'biased');

% Fit AR Model with Different p Values**
figure;
hold on;
legend_entries = {};
error = zeros(1, length(p_values)); % Store mean square error (MSE)

for i = 1:length(p_values)
    p = p_values(i);
    
    % Compute PSD of AR(p) model
    [AR_Coeff_Est, sigma_2_Est] = fAREst(acf_biased, p);
    PSD_estimated = fARPSD(AR_Coeff_Est, sigma_2_Est, nf, '');
    error(i) = mean((PSD_true - PSD_estimated) .^2); % Compute MSE

    % Plot PSD for different orders
    plot(w, 10*log10(PSD_estimated(1:nf/2+1)), 'LineWidth', 1.2);
    legend_entries{end+1} = ['AR(', num2str(p), ')']; % Update legend
end

% Plot True PSD**
plot(w, 10*log10(PSD_true(1:nf/2+1)), 'k', 'LineWidth', 2); % Bold true curve
grid on;
xlabel('Frequency (Hz)');
ylabel('Power Spectral Density (dB)');
title('PSD Estimation using AR Model (Different Orders)');
legend([legend_entries, 'True AR(4) Model'], 'Location', 'Best'); % Update legend

% Plot Optimal Result**
figure;
subplot(2,1,1);
semilogy(p_values, error, '-ob', 'LineWidth', 1.5);
xlabel('p'); 
ylabel('Mean Square Error','FontSize',12,'interpreter','latex'); 
grid on;

% Select model order with the minimum MSE
[~, best_p_idx] = min(error);
best_p = p_values(best_p_idx);

[AR_Coeff_Est, sigma_2_Est] = fAREst(acf_biased, best_p); % Best estimated PSD
PSD_estimated_dB = fARPSD(AR_Coeff_Est, sigma_2_Est, nf, 'dB');
PSD_true_dB = fARPSD(a, sigma_2, nf, 'dB'); % Compute true PSD

subplot(2,1,2);
plot(w, PSD_true_dB(1:nf/2+1), '-b', 'LineWidth', 1.5);
hold on;
plot(w, PSD_estimated_dB(1:nf/2+1), '-r', 'LineWidth', 1.5);
grid on;
xlabel('Frequency (Hz)');
ylabel('Power Spectral Density (dB)');
legend('True PSD', ['Best Estimated PSD (p=' num2str(best_p) ')']);
