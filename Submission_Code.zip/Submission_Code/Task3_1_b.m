clc; clear; close all;
addpath('./wind-dataset/');
% 设置数据文件名
wind_files = {'low-wind.mat', 'medium-wind.mat', 'high-wind.mat'};
wind_labels = {'Low Wind', 'Medium Wind', 'High Wind'};

% 参数设置
mu = [0.1, 0.01,0.001]; % 学习率
M_values = 1:30; % 滤波器阶数范围
num_trials = 100; % 独立实验次数（取均值以平滑曲线）

% 预分配 MPSE 存储矩阵
MPSE_CLMS = zeros(length(M_values), length(wind_files));
MPSE_ACLMS = zeros(length(M_values), length(wind_files));

%% 绘制风速数据的 Scatter Diagrams
figure;
for w = 1:length(wind_files)
    % 加载数据
    data = load(wind_files{w});
    v_east = data.v_east; % 东向风速
    v_north = data.v_north; % 北向风速
    v = v_east + 1j * v_north; % 生成复数风信号
    N = length(v);

    % 绘制 Circularity Plot
    subplot(1, 3, w);
    scatter(real(v), imag(v), 10, 'b', 'filled');
    grid on;
    xlabel('Real Part (East-West)');
    ylabel('Imaginary Part (North-South)');
    title(['Scatter Plot: ', wind_labels{w}]);
end
set(gcf, 'Position', [100, 100, 1200, 400]);

%% 计算不同滤波器阶数下的 MPSE
for w = 1:length(wind_files)
    % 加载数据
    data = load(wind_files{w});
    v_east = data.v_east; % 东向风速
    v_north = data.v_north; % 北向风速
    v = v_east + 1j * v_north; % 生成复数风信号
    N = length(v);
    
    for m_idx = 1:length(M_values)
        M = M_values(m_idx); % 当前滤波器阶数
        errors_CLMS = zeros(1, N-M);
        errors_ACLMS = zeros(1, N-M);
        
        for i = 1:num_trials
            % CLMS 初始化
            h_CLMS = zeros(M, 1);
            error_CLMS = zeros(1, N-M);
            
            % ACLMS 初始化
            h_ACLMS = zeros(M, 1);
            g_ACLMS = zeros(M, 1);
            error_ACLMS = zeros(1, N-M);
            
            for n = M+1:N
                x_segment = v(n-1:-1:n-M);
                
                % CLMS 预测
                y_hat_CLMS = h_CLMS' * x_segment;
                error_CLMS(n-M) = v(n) - y_hat_CLMS;
                h_CLMS = h_CLMS + mu(w) * conj(error_CLMS(n-M)) * x_segment;

                % ACLMS 预测
                y_hat_ACLMS = h_ACLMS' * x_segment + g_ACLMS' * conj(x_segment);
                error_ACLMS(n-M) = v(n) - y_hat_ACLMS;
                h_ACLMS = h_ACLMS + mu(w) * conj(error_ACLMS(n-M)) * x_segment;
                g_ACLMS = g_ACLMS + mu(w) * conj(error_ACLMS(n-M)) * conj(x_segment);
            end
            
            % 记录误差平方
            errors_CLMS = errors_CLMS + abs(error_CLMS).^2;
            errors_ACLMS = errors_ACLMS + abs(error_ACLMS).^2;
        end
        
        % 计算 MPSE (均方预测误差)
        MPSE_CLMS(m_idx, w) = pow2db(mean(errors_CLMS / num_trials));
        MPSE_ACLMS(m_idx, w) = pow2db(mean(errors_ACLMS / num_trials));
    end
end

%% 绘制 MPSE 曲线
figure;
for w = 1:length(wind_files)
    subplot(1, 3, w);
    plot(M_values, MPSE_CLMS(:, w), 'b', 'LineWidth', 1.5); hold on;
    plot(M_values, MPSE_ACLMS(:, w), 'r', 'LineWidth', 1.5);
    xlabel('Filter order M');
    ylabel('MPSE (dB)');
    title(wind_labels{w});
    legend('CLMS', 'ACLMS');
    grid on;
end
set(gcf, 'Position', [100, 100, 1200, 400]); % 调整图像大小



