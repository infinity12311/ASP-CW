clc; clear; close all;
addpath('./EEG_Data/');
%% ========== 1. 加载EEG数据并选取一个片段 (长度1200) ==========
% 假设当前文件夹下有 'EEG_Data_Assignment1.mat'，包含变量 POz, fs
data = load('EEG_Data_Assignment1.mat');  % 里面应有 POz, fs
POz_all = data.POz;  % EEG信号
fs = data.fs;        % 采样频率, e.g. 1200 Hz

N = 1200;      % 取片段长度
a = 60000;     % 片段起始位置，可自行修改
y = POz_all(a : a+N-1).';  % 转为行向量 (1×N) 方便后续处理

%% ========== 2. 定义 DFT-CLMS 输入向量 x(n) ==========
% 参考 3.3(c) 中的式(41)，在长度 N 下构造:
%   x(n) = (1/N)* [1, e^{j2πn/N}, e^{j4πn/N}, ..., e^{j2π(N-1)n/N}]^T
% 其中 n = 0,1,...,N-1
M = N;  % 输入向量的维度 = N
xFun = @(n) (1/N)*exp(1j*2*pi*(0:M-1)*n/N).';  % 返回大小为 M×1 的列向量

%% ========== 3. 初始化 DFT-CLMS 参数 ==========
mu = 1;               % 根据Widrow等人的结论，DFT-CLMS常用 mu=1
wMat = zeros(M, N+1); % 存储每个时刻的权值向量 (M×(N+1))
e = zeros(1, N);      % 误差存储

%% ========== 4. 进行DFT-CLMS在线迭代 ==========
for n = 1:N
    x_n = xFun(n-1);            % 对应时刻 n 的输入向量, n-1 是指数里的时间索引
    y_hat = wMat(:,n)' * x_n;   % 预测输出
    e(n) = y(n) - y_hat;        % 误差
    wMat(:,n+1) = wMat(:,n) + mu * conj(e(n)) * x_n;  % 权值更新
end

%% ========== 5. 绘制时间-频率图 (|w(k,n)|) ==========
% wMat(k,n) 表示迭代到第 n-1 步时, 第 k 个“频率”上的系数
% 取 wMat(:,2:end) 代表从第1次更新到第N次更新的结果
W_mag = abs(wMat(:, 2:end));  % 大小 M×N

% 频率轴: k=0~(M-1) => freq_k = (k * fs)/N
freqAxis = (0:M-1)*(fs/N);
timeAxis = 1:N;

figure;
imagesc(timeAxis, freqAxis, W_mag);
axis xy;  % 让频率从小到大
xlabel('Time index (sample)');
ylabel('Frequency (Hz)');
title('DFT-CLMS Time-Frequency Diagram of EEG Segment');
colorbar;
colormap jet;
ylim([0,60])

%% ========== 6. 观察结果并说明 =========%
% 由于 DFT-CLMS 相当于每个时刻对傅里叶基系数做一次更新，并不是真正的瞬时功率谱，
% 因此你会看到的 "时频图" 可能不如短时傅里叶变换(STFT) 或 AR-CLMS 那样能清晰反映EEG的
% 真实频率随时间变化的细节。它更多体现了“信号在固定DFT基下”的逐点迭代过程。
