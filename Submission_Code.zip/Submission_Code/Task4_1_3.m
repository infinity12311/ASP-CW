clear; clc; close all;
% 加载数据
load('time-series.mat'); % 假设 y 变量存储于此
y = y(:); % 确保 y 为列向量
N = length(y); % 样本数

% 去除均值
y_mean = mean(y);
y_zero_mean = y - y_mean;

% 初始化参数
mu = 1e-5; % 学习率
order = 4; % AR(4) 预测模型
w = zeros(order, 1); % 初始化权重
y_pred = zeros(N, 1); % 预测输出
e = zeros(N, 1); % 误差信号

% 选择 a 值范围（推荐范围 0.5 到 2）
a = 82; % 你可以调整这个值，例如 a = 0.5, 1, 1.5, 2 进行比较

% 使用 a * tanh 作为激活函数
for n = order+1:N
    x_n = y_zero_mean(n-1:-1:n-order); % 取 y[n-1] 到 y[n-4] 作为输入
    y_pred(n) = a * tanh(w' * x_n); % 预测值 (带缩放因子的非线性激活)
    e(n) = y_zero_mean(n) - y_pred(n); % 误差计算
    w = w + mu * e(n) * x_n; % LMS 权重更新
end

% 计算均方误差 (MSE) 和预测增益 (Rp)
sigma_yhat2 = var(y_pred); % 计算信号 y 的方差
sigma_e2 = var(e); % 计算预测误差的方差
Rp = 10 * log10(sigma_yhat2 / sigma_e2); % 计算预测增益 (dB)

% 绘制结果
figure;
plot(y_zero_mean, 'b', 'DisplayName', 'Zero-mean y[n]');
hold on;
plot(y_pred, 'r--', 'DisplayName', ['Predicted y[n] with a * tanh, a = ' num2str(a)]);
legend;
xlabel('Sample Index');
ylabel('Amplitude');
title(['Scaled Activation LMS Prediction: MSE = ', num2str(sigma_e2), ', Rp = ', num2str(Rp), ' dB']);
grid on;
hold off;
