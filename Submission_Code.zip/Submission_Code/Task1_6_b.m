clc; clear; close all;
addpath('./Function/');

%% **Step 1: Load Data**
load('PCAPCR.mat');  % Ensure that PCAPCR.mat is in the current directory

%% **Step 2: Compute SVD**
% Perform SVD on X
[U, S, V] = svd(X);
sigma_X = diag(S); % Singular values of X

% Perform SVD on X_noise
[U_noise, S_noise, V_noise] = svd(Xnoise);
sigma_X_noise = diag(S_noise); % Singular values of X_noise

%% **Step 3: Select r Most Important Principal Components**
% Set r = rank(X) (Can use the empirical rule: choose singular values covering 99% energy)
energy_ratio = cumsum(sigma_X) / sum(sigma_X);
r = find(energy_ratio > 0.95, 1); % Choose the number of principal components covering 95% energy

% Retain only the first r principal components to construct X_tilde_noise
S_tilde = S_noise;
S_tilde(r+1:end, r+1:end) = 0; % Retain only the first r singular values
X_denoise = U_noise * S_tilde * V_noise';

%% **Step 4: Compute Mean Square Error (MSE)**
% **Compute MSE between X_noise and X_tilde_noise (per column)**
MSE_X_noise_col = mean((X - Xnoise).^2, 1);  % X vs X_noise
MSE_X_tilde_col = mean((X - X_denoise).^2, 1);  % X vs X_tilde_noise

%% **Step 5: Plot Error Comparison**
figure;

% **First Plot: Singular Values of X, X_noise, and X_tilde_noise (Using STEM Plot)**
subplot(2,1,1);
stem(1:length(sigma_X), sigma_X, 'bo', 'LineWidth', 1.2); hold on;
stem(1:length(sigma_X_noise), sigma_X_noise, 'r.', 'LineWidth', 1.2, 'MarkerSize', 12);
stem(1:length(sigma_X_noise), diag(S_tilde), 'go', 'LineWidth', 1.2);
xlabel('Singular Value Index');
ylabel('Singular Value');
title('Singular Values of X (blue), X_{noise} (red), and X_{denoise} (green)');
legend('X', 'X_{noise}', 'X_{denoise}');
grid on;

% **Second Plot: Error Comparison (Using STEM Plot)**
subplot(2,1,2);
stem(1:length(MSE_X_noise_col), MSE_X_noise_col, 'ro', 'LineWidth', 1.5); hold on;
stem(1:length(MSE_X_tilde_col), MSE_X_tilde_col, 'go', 'LineWidth', 1.5);
xlabel('Column Index');
ylabel('Mean Square Error');
title('MSE Comparison: X vs Xnoise (Red) & X vs Xdenoise (Blue)');
legend('X vs Xnoise', 'X vs Xdenoise');
grid on;

disp(['✅ Low-rank approximation X_tilde_noise completed!']);
