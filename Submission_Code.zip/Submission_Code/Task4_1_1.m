clear; clc; close all;
% 加载数据
load('time-series.mat'); % 假设y是从.mat文件导入的
y = y(:); % 确保y是列向量
N = length(y); % 计算样本数

% 去除均值
y_mean = mean(y);
y_zero_mean = y - y_mean;

% 初始化LMS算法
mu = 1e-5; % 学习率
order = 4; % AR(4)模型
w = zeros(order, 1); % 初始化权重
y_pred = zeros(N, 1); % 预测输出
e = zeros(N, 1); % 误差信号

% LMS算法进行一步预测
for n = order+1:N
    x_n = y_zero_mean(n-1:-1:n-order); % 取 y[n-1] 到 y[n-4] 作为输入
    y_pred(n) = w' * x_n; % 计算预测值
    e(n) = y_zero_mean(n) - y_pred(n); % 计算误差
    w = w + mu * e(n) * x_n; % LMS权重更新
end

% 计算均方误差 (MSE) 和预测增益 (Rp)
sigma_yhat2 = var(y_pred); % 计算信号y的方差
sigma_e2 = var(e); % 计算预测误差的方差
Rp = 10 * log10(sigma_yhat2 / sigma_e2); % 计算预测增益 (dB)

% 绘制结果
figure;
plot(y_zero_mean, 'b', 'DisplayName', 'Zero-mean y[n]');
hold on;
plot(y_pred, 'r--', 'DisplayName', 'Predicted y[n]');
legend;
xlabel('Sample Index');
ylabel('Amplitude');
title(['LMS Prediction: MSE = ', num2str(sigma_e2), ', Rp = ', num2str(Rp), ' dB']);
grid on;
hold off;
