%% ========== 参数与初始化 ==========
clear; clc; close all;

% --- AR(2) 系数与噪声 ---
a1 = 0.1;
a2 = 0.8;
sigma2_eta = 0.25;

% --- LMS 相关 ---
mu_list = [0.05, 0.01];   % 要对比的两个步长
M = 2;                    % 滤波器阶数(预测器用 x(n-1), x(n-2))
N = 1000;                 % 每次试验的数据长度
numReal = 100;            % 重复试验次数
steadyStart = 901;        % 稳态区起始点(取最后100点)

% 用于存储稳态权值, 大小: (length(mu_list) x numReal x M)
w_steady_all = zeros(length(mu_list), numReal, M);

%% ========== 1. 对不同步长分别进行多次试验 ==========
for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);

    for realization = 1:numReal
        % --- (a) 生成 AR(2) 数据 ---
        w_noise = sqrt(sigma2_eta)*randn(N,1);
        x = zeros(N,1);
        x(1) = 0; x(2) = 0;  % 初值
        for n = 3:N
            x(n) = a1*x(n-1) + a2*x(n-2) + w_noise(n);
        end

        % --- (b) 初始化 LMS ---
        wLMS = zeros(M,1);   % 权值向量 [w1; w2]
        w_record = zeros(M,N);  % 用于记录每一步的权值

        % --- (c) 逐点在线更新 ---
        for n = 3:N
            u = [x(n-1); x(n-2)];   % 输入向量
            x_hat = wLMS' * u;     % 预测输出
            e_n = x(n) - x_hat;    % 误差
            % LMS 更新
            wLMS = wLMS + mu * e_n * u;
            % 记录当下权值
            w_record(:,n) = wLMS;
        end

        % --- (d) 取稳态区间(最后100点)做平均 ---
        w_steady_all(mu_idx, realization, :) = ...
            mean(w_record(:, steadyStart:end), 2)';
    end
end

%% ========== 2. 对每个 mu, 计算100次试验的平均稳态系数 ==========
w_avg_final = zeros(length(mu_list), M);  % 大小 (2 x 2), 存 [w1, w2]
for mu_idx = 1:length(mu_list)
    w_avg_final(mu_idx,:) = mean( squeeze(w_steady_all(mu_idx,:,:)), 1 );
end

%% ========== 3. 显示结果并与真实系数比较 ==========
true_coeff = [a1, a2];
fprintf('\n=== 真实AR(2)系数: (a1, a2) = (%.3f, %.3f) ===\n', a1, a2);

for mu_idx = 1:length(mu_list)
    mu = mu_list(mu_idx);
    w_est = w_avg_final(mu_idx,:);
    fprintf('\n--- 步长 mu = %.3f ---\n', mu);
    fprintf('平均稳态系数估计: [w1, w2] = [%.4f, %.4f]\n', w_est(1), w_est(2));
    fprintf('与真实值差异: [%.4f, %.4f]\n', abs(w_est(1)-a1), abs(w_est(2)-a2));
end
