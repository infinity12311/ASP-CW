clc; clear; close all;

%% **Step 1: Load EEG Data**
data_path = fullfile('EEG_Data', 'EEG_Data_Assignment1.mat'); % Specify file path
load(data_path);  % Load POz channel data and sampling rate fs

eeg_signal = POz;  % Select POz channel EEG data
fs = double(fs);  % Ensure fs is of type double
N = length(eeg_signal);  % EEG data length
nfft = N;
time = (0:N-1)/fs;  % Time axis (seconds)

%% **Step 2: Compute Standard Periodogram**
[PSD_standard, f_standard] = periodogram(eeg_signal, [], nfft, fs);

% Plot Standard Periodogram
figure;
plot(f_standard, 10*log10(PSD_standard), 'b', 'LineWidth', 1.5);
xlabel('Frequency (Hz)');
ylabel('Power Spectral Density (dB)');
title('Standard Periodogram of EEG (POz)');
grid on;

%% **Step 3: Compute Averaged Periodogram (Different Window Sizes)**
window_sizes = [10, 5, 1];  % Window sizes (seconds)
figure;
Pxx_all = {}; % Store PSD computed for different windows
f_welch_all = {};

for i = 1:length(window_sizes)
    win_len = window_sizes(i) * fs;  % Compute window length (samples)
    noverlap = round(0.5 * win_len);  % 50% overlap
    [Pxx, f_welch] = pwelch(eeg_signal, hamming(win_len), [], nfft, fs);
    
    % Store data
    Pxx_all{i} = Pxx;
    f_welch_all{i} = f_welch;

    % Plot Averaged Periodogram
    subplot(3,1,i);
    plot(f_welch, 10*log10(Pxx), 'r', 'LineWidth', 1.5);
    xlabel('Frequency (Hz)');
    ylabel('Power (dB)');
    title(['Averaged Periodogram (Window = ', num2str(window_sizes(i)), ' s)']);
    grid on;
end

%% **Step 4: Identify SSVEP Response Peaks (Based on Averaged Periodogram)**
ssvep_freqs = 11:20;  % Expected SSVEP frequency range

figure;
colors = {'r', 'g', 'b'}; % Color codes: red, green, blue
legends = {}; % Legend labels

for i = 1:length(window_sizes)
    Pxx = Pxx_all{i};
    f_welch = f_welch_all{i};

    % Plot Welch Periodogram for different window sizes
    plot(f_welch, 10*log10(Pxx), colors{i}, 'LineWidth', 1.5); hold on;
    legends{end+1} = ['Averaged Periodogram (', num2str(window_sizes(i)), 's)'];
end

xlabel('Frequency (Hz)');
ylabel('Power Spectral Density (dB)');
title('Comparison of Averaged Periodograms (Different Window Sizes)');
legend(legends, 'Location', 'Northeast');
xlim([11 20]); % Show only 11-20Hz
grid on;

%% **Step 5: Compare Standard Periodogram and 10s Averaged Periodogram**
figure;
Pxx_10s = Pxx_all{1}; % Select 10s window Welch PSD
f_10s = f_welch_all{1};

plot(f_standard, 10*log10(PSD_standard), 'b', 'LineWidth', 1.5); hold on;
plot(f_10s, 10*log10(Pxx_10s), 'r', 'LineWidth', 1.5);
xlabel('Frequency (Hz)');
ylabel('Power Spectral Density (dB)');
title('Comparison: Standard Periodogram vs Averaged Periodogram (10s Window)');
legend('Standard Periodogram', 'Averaged Periodogram (10s)');
xlim([11 20]); % Show only 11-20Hz
grid on;
