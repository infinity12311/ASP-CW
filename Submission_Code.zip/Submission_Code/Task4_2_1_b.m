clear; clc; close all;
% 生成时间序列
t = ((2*pi)/100):((2*pi)/100):10*pi; 

% 生成基准信号 y1, y2, y3
y1 = sin(t);      % 频率 1
y2 = sin(0.5*t);  % 频率较低
y3 = sin(4*t);    % 频率较高

% 生成待分类的测试信号 (可修改)
y_test = sin(4*t); % 这里测试 y3, 你可以换成 y1 或 y2

% 计算输入信号 y_test 与 y1, y2, y3 的卷积
conv_y1 = conv(y_test, y1, 'same');
conv_y2 = conv(y_test, y2, 'same');
conv_y3 = conv(y_test, y3, 'same');

% 计算卷积结果的特征
feature_mean = [mean(abs(conv_y1)), mean(abs(conv_y2)), mean(abs(conv_y3))]; % 取绝对值均值
feature_max = [max(abs(conv_y1)), max(abs(conv_y2)), max(abs(conv_y3))]; % 取最大峰值

% 计算最终匹配得分 (可以调整权重)
score = feature_mean + feature_max;

% 找到最高得分的类别
[~, predicted_class] = max(score);

% 输出预测结果
fprintf('Predicted Signal: y%d\n', predicted_class);

% 绘图：显示 y_test 及其与 y1, y2, y3 的卷积结果
figure;

% 原始测试信号
subplot(4,1,1);
plot(t, y_test, 'k');
title('Test Signal');
xlabel('Time');
ylabel('Amplitude');
grid on;

% y_test 与 y1 卷积
subplot(4,1,2);
plot(t, conv_y1, 'b');
title('Convolution with y1');
xlabel('Time');
ylabel('Amplitude');
grid on;

% y_test 与 y2 卷积
subplot(4,1,3);
plot(t, conv_y2, 'r');
title('Convolution with y2');
xlabel('Time');
ylabel('Amplitude');
grid on;

% y_test 与 y3 卷积
subplot(4,1,4);
plot(t, conv_y3, 'g');
title('Convolution with y3');
xlabel('Time');
ylabel('Amplitude');
grid on;
