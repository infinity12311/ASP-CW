clc; clear; close all;
addpath('./Function/');

%% c
%% **Step 1: Load Data**
load('PCAPCR.mat');  % Load data

%% **Step 2: Compute OLS Estimate**
B_OLS = (Xnoise' * Xnoise) \ (Xnoise' * Y); % OLS estimate B
Y_OLS = Xnoise * B_OLS;  % Compute predicted values on training data

%% **Step 3: Compute PCR Estimate**
% Perform SVD on Xnoise
[U, S, V] = svd(Xnoise, 'econ');
sigma_X_noise = diag(S); % Singular values of X_noise

% Select r most important principal components
energy_ratio = cumsum(sigma_X_noise) / sum(sigma_X_noise);
r = find(energy_ratio > 0.4, 1); % Choose the number of principal components covering 40% energy

% Compute PCR estimate
Ur = U(:, 1:r);
Sr = S(1:r, 1:r);
Vr = V(:, 1:r);
B_PCR = Vr * (Sr \ (Ur' * Y)); % PCR estimate B
X_tilde_noise = Ur * Sr * Vr'; % Low-rank approximation of X_noise
Y_PCR = X_tilde_noise * B_PCR; % Compute predicted values on training data

%% **Step 4: Compute MSE**
MSE_OLS = mean((Y - Y_OLS).^2, 'all'); % OLS error
MSE_PCR = mean((Y - Y_PCR).^2, 'all'); % PCR error

disp(['✅ OLS MSE: ', num2str(MSE_OLS)]);
disp(['✅ PCR MSE: ', num2str(MSE_PCR)]);

%% **Step 5: Evaluate OLS and PCR on Test Data**
Y_test_OLS = Xtest * B_OLS;  % OLS prediction on test set
Y_test_PCR = Xtest * B_PCR;  % PCR prediction on test set

% Compute MSE for test data
MSE_test_OLS = mean((Ytest - Y_test_OLS).^2, 'all');
MSE_test_PCR = mean((Ytest - Y_test_PCR).^2, 'all');

disp(['✅ Test Data OLS MSE: ', num2str(MSE_test_OLS)]);
disp(['✅ Test Data PCR MSE: ', num2str(MSE_test_PCR)]);

%% **Step 6: Visualize Error Comparison**
figure;
bar([MSE_OLS, MSE_PCR; MSE_test_OLS, MSE_test_PCR]);
set(gca, 'XTickLabel', {'Train', 'Test'});
ylabel('Mean Squared Error');
legend('OLS', 'PCR');
title('MSE Comparison for OLS and PCR');
grid on;
